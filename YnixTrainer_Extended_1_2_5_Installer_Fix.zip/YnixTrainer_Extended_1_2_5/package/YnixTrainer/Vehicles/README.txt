YnixTrainer Extended 1.2.4 - vehicle database and compatibility notes

Canonical database: vehicles.json
Compatibility copies: vehicle_catalog.json and ..\vehicle_catalog.json

The database contains 470 validated model records. The separate addons.json contains 85 more records; 15 model codes overlap, so the merged list contains 540 unique models.
The spawner reads scripts\YnixTrainer\Vehicles\vehicles.json first, then checks
legacy-compatible locations for vehicle_catalog.json / vehicles.json and the
extensionless legacy filename vehicle_catalog.

Editing this JSON changes the local spawner list; it does not install add-on
vehicle models into GTA V. An add-on vehicle still requires its own game assets
and the correct meta/resource installation in the game.
