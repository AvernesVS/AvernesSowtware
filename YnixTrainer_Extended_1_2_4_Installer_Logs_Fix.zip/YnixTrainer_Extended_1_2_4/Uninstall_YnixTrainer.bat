@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "GTAV_DIR=%~1"
if not defined GTAV_DIR set "GTAV_DIR=C:\Program Files (x86)\Grand Theft Auto V"
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
if not exist "%GTAV_DIR%\scripts" call :prompt_game_path
if not exist "%GTAV_DIR%\scripts" (
  echo [ERROR] GTA V scripts folder was not found.
  pause
  exit /b 1
)

set "SCRIPTS_DIR=%GTAV_DIR%\scripts"
set "BACKUP_DIR=%SCRIPTS_DIR%\YnixTrainer_Backups"
set "RESTORED="

if exist "%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_4.bak" (
  copy /y "%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_4.bak" "%SCRIPTS_DIR%\YnixTrainerExtended.dll" >nul
  if not errorlevel 1 set "RESTORED=1"
)
if not defined RESTORED call :restore_any_backup
if not defined RESTORED if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll" del /q "%SCRIPTS_DIR%\YnixTrainerExtended.dll"
if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" del /q "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new"

echo YnixTrainer Extended script DLL was removed or previous DLL was restored.
echo User data in scripts\YnixTrainer and backups were intentionally kept.
echo Remove those folders manually only if you also want to delete settings and custom lists.
pause
exit /b 0

:prompt_game_path
echo GTA V scripts folder was not found in the default location.
set "GTAV_DIR="
set /p "GTAV_DIR=Enter GTA V root folder: "
if not defined GTAV_DIR exit /b 1
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
exit /b 0

:restore_any_backup
for %%F in ("%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_4_*.bak") do if exist "%%~fF" (
  copy /y "%%~fF" "%SCRIPTS_DIR%\YnixTrainerExtended.dll" >nul
  if not errorlevel 1 (
    set "RESTORED=1"
    exit /b 0
  )
)
exit /b 1
