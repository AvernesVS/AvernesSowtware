# Native references used by Max Tuning

The implementation uses the following GTA V vehicle natives:

| Native | Hash | Purpose |
|---|---|---|
| SET_VEHICLE_MOD_KIT | `0x1F2AA07F00B3217A` | Assign mod kit 0 before querying or applying parts |
| GET_NUM_VEHICLE_MODS | `0xE38E9162A2500646` | Read the available count for a slot |
| SET_VEHICLE_MOD | `0x6AF0636DDEDCB6DD` | Apply the highest available index in a normal slot |
| GET_VEHICLE_MOD | `0x772960298DA26FDB` | Verify the selected index |
| TOGGLE_VEHICLE_MOD | `0x2A1F4F37F95BAD08` | Enable turbo, tyre smoke and xenon |
| IS_TOGGLE_MOD_ON | `0x84B233A8C8FC8AE7` | Verify toggle state |
| GET_VEHICLE_LIVERY_COUNT | `0x87B63E25A529D526` | Detect texture livery availability |
| SET_VEHICLE_LIVERY | `0x60BF608F1B8CD1B6` | Apply the highest texture livery |

The three toggle-only mod types used here are 18 (turbo), 20 (tyre smoke), and 22 (xenon lights). Other available mod slots in the 0–49 range are queried and set as indexed mods. A vehicle without a compatible mod kit may expose no available slots.

References:
- https://github.com/citizenfx/natives/blob/master/VEHICLE/SetVehicleMod.md
- https://cfxnatives.dev/natives/GET_NUM_VEHICLE_MODS
- https://cfxnatives.dev/natives/IS_TOGGLE_MOD_ON
- https://cfxnatives.dev/natives/GET_VEHICLE_LIVERY_COUNT
