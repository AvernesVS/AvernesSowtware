using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;

namespace YnixTrainerExtended
{
    public sealed class YnixTrainerExtendedScript : Script
    {
        private const string ProductName = "YnixTrainer Extended";
        private const string ProductVersion = "1.2.6";
        private const int AmmoPerWeapon = 9999;
        private const int PremiumWeaponTint = 7;

        private const int StoryCashLimit = Int32.MaxValue;

        private readonly string _gameDirectory;
        private readonly string _scriptsDirectory;
        private readonly string _dataDirectory;
        private readonly string _vehiclesDirectory;
        private readonly string _logDirectory;
        private readonly string _errorLogPath;
        private readonly string _crashReportPath;
        private readonly string _legacyLogPath;
        private readonly object _logSync = new object();
        private readonly string _sourceConfigPath;
        private readonly string _configPath;
        private readonly string _addonPath;
        private readonly string _vehicleCatalogPath;
        private readonly string _legacyVehicleCatalogPath;
        private readonly string _favoriteLocationsPath;
        private readonly string _logPath;
        private readonly TrainerSettings _settings;
        private readonly Dictionary<string, List<MenuEntry>> _pages;
        private readonly Stack<string> _pageStack;
        private readonly List<AddonVehicle> _addonVehicles;
        private readonly List<AddonVehicle> _vehicleCatalog;
        private readonly List<FavoriteLocation> _favoriteLocations;
        private readonly List<string> _vehicleCategoryPageKeys;
        private readonly string[] _weaponNames;
        private readonly string[] _weaponComponentNames;

        private bool _menuOpen;
        private string _currentPage;
        private int _selectedIndex;
        private int _scrollOffset;
        private bool _autoLoadoutGranted;
        private bool _originalModelCaptured;
        private uint _originalModelHash;
        private readonly List<int> _bodyguards = new List<int>();
        private int _lastWeatherApplyTick;
        private bool _clockPauseWasSet;
        private bool _weatherWasLocked;
        private bool _infiniteAmmoWasApplied;
        private int _lastProtectedVehicleHandle;
        private bool _aborted;
        private int _addonIndex;
        private string _lastLoggedError;
        private DateTime _lastLoggedErrorUtc;
        private DateTime _lastErrorNotificationUtc;
        private DateTime _hideCashChangeUntilUtc;
        private bool _vehicleSearchInputPending;
        private string _vehicleSearchQuery;
        private int _pendingVehicleDeleteHandle;
        private bool _vehicleSpawnPending;
        private int _pendingVehicleModelHash;
        private string _pendingVehicleModelName;
        private string _pendingVehicleDisplayName;
        private DateTime _pendingVehicleSpawnDeadlineUtc;
        private int _bodyguardGroupId = -1;
        private uint _bodyguardRelationshipGroupHash;
        private int _lastBodyguardFollowTick;
        private bool _noClipWasActive;
        private bool _nitroTrailerWarningShown;
        private readonly Dictionary<int, uint> _trainerSpawnedVehicleHashes = new Dictionary<int, uint>();
        private bool _waypointTeleportPending;
        private bool _waypointTeleportPrepared;
        private int _waypointTeleportEntityHandle;
        private float _waypointTeleportX;
        private float _waypointTeleportY;
        private Vector3 _waypointTeleportOriginalPosition;
        private DateTime _waypointTeleportDeadlineUtc;
        private bool _skinSnapshotCaptured;
        private bool _pendingSkinStateRestore;
        private bool _clearSkinSnapshotAfterRestore;
        private int _suppressPauseControlsFrames;
        private int _skinRestoreFrames;
        private Vector3 _skinRestorePosition;
        private float _skinRestoreHeading;
        private int _skinRestoreHealth;
        private int _skinRestoreArmour;
        private uint _skinSelectedWeapon;
        private readonly List<WeaponSnapshot> _skinWeaponSnapshot = new List<WeaponSnapshot>();

        private static string ResolveGameDirectory()
        {
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            try
            {
                string fullPath = Path.GetFullPath(baseDirectory);
                string folderName = Path.GetFileName(fullPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
                if (String.Equals(folderName, "scripts", StringComparison.OrdinalIgnoreCase))
                {
                    DirectoryInfo parent = Directory.GetParent(fullPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
                    if (parent != null) return parent.FullName;
                }
                return fullPath;
            }
            catch
            {
                return baseDirectory;
            }
        }

        public YnixTrainerExtendedScript()
        {
            _gameDirectory = ResolveGameDirectory();
            _scriptsDirectory = Path.Combine(_gameDirectory, "scripts");
            _dataDirectory = Path.Combine(_scriptsDirectory, "YnixTrainer");
            _vehiclesDirectory = Path.Combine(_dataDirectory, "Vehicles");
            _logDirectory = Path.Combine(_scriptsDirectory, "YnixTrainer_Logs");
            _sourceConfigPath = Path.Combine(_dataDirectory, "Config.ini");
            _configPath = Path.Combine(_dataDirectory, "YnixTrainerExtended.ini");
            _addonPath = Path.Combine(_dataDirectory, "addons.json");
            _vehicleCatalogPath = Path.Combine(_vehiclesDirectory, "vehicles.json");
            _legacyVehicleCatalogPath = Path.Combine(_dataDirectory, "vehicle_catalog.json");
            _favoriteLocationsPath = Path.Combine(_dataDirectory, "favorite_locations.json");
            _logPath = Path.Combine(_logDirectory, "session.log");
            _errorLogPath = Path.Combine(_logDirectory, "errors.log");
            _crashReportPath = Path.Combine(_logDirectory, "crash_report.log");
            _legacyLogPath = Path.Combine(_dataDirectory, "YnixTrainerExtended.log");
            _vehicleSearchQuery = String.Empty;

            _settings = new TrainerSettings();
            _pages = new Dictionary<string, List<MenuEntry>>(StringComparer.OrdinalIgnoreCase);
            _pageStack = new Stack<string>();
            _addonVehicles = new List<AddonVehicle>();
            _vehicleCatalog = new List<AddonVehicle>();
            _favoriteLocations = new List<FavoriteLocation>();
            _vehicleCategoryPageKeys = new List<string>();

            _weaponNames = BuildWeaponCatalog();
            _weaponComponentNames = BuildWeaponComponentCatalog();

            Interval = 0;
            Tick += OnTick;
            KeyDown += OnKeyDown;
            Aborted += OnAborted;
            AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;
            AppDomain.CurrentDomain.ProcessExit += OnDomainProcessExit;

            try
            {
                Directory.CreateDirectory(_scriptsDirectory);
                Directory.CreateDirectory(_dataDirectory);
                Directory.CreateDirectory(_vehiclesDirectory);
                Directory.CreateDirectory(_logDirectory);
            }
            catch (Exception ex)
            {
                LogException("Create data directory", ex);
            }

            Log("Startup reached script constructor. BaseDirectory=" + AppDomain.CurrentDomain.BaseDirectory +
                "; gameDirectory=" + _gameDirectory + "; scriptsDirectory=" + _scriptsDirectory +
                "; assembly=" + GetType().Assembly.Location);

            try { LoadFavoriteLocations(); }
            catch (Exception ex) { LogException("LoadFavoriteLocations", ex); }

            // Build the menu independently: malformed settings or JSON must not
            // prevent the trainer from opening so the user can still inspect/fix it.
            try { BuildMenus(); }
            catch (Exception ex) { LogException("BuildMenus", ex); }

            try { LoadSettings(); }
            catch (Exception ex) { LogException("LoadSettings", ex); }

            try { LoadVehicleCatalog(); }
            catch (Exception ex) { LogException("LoadVehicleCatalog", ex); }

            try { LoadAddonVehicles(); }
            catch (Exception ex)
            {
                LogException("LoadAddonVehicles", ex);
                try { RebuildVehicleSpawnerMenu(); } catch (Exception rebuildEx) { LogException("RebuildVehicleSpawnerMenu", rebuildEx); }
            }

            Notify(ProductName + " " + ProductVersion + " loaded. Press F11 to open.");
            Log("Initialized. Original YnixTrainer files were not modified. Vehicle DB: " + _vehicleCatalogPath +
                "; diagnostics: " + _logDirectory);
        }

        private void OnTick(object sender, EventArgs e)
        {
            if (_aborted) return;
            try
            {
                // Keep pause/front-end controls disabled while the trainer is open and
                // for several script ticks after closing it. GTA can process the same
                // ESC press after ScriptHookVDotNet raises KeyDown, so one frame is not
                // sufficient on every game/build configuration.
                if (_menuOpen || _suppressPauseControlsFrames > 0)
                {
                    BlockMenuGameControls();
                    if (!_menuOpen && _suppressPauseControlsFrames > 0)
                        _suppressPauseControlsFrames--;
                }

                // GTA's CASH_CHANGE HUD component is the floating "+$amount" popup.
                // Hide only that component briefly after our Story Mode cash update;
                // the normal cash balance remains visible.
                if (DateTime.UtcNow < _hideCashChangeUntilUtc)
                    Function.Call((Hash)0x6806C51AD12B83B8UL, 13); // HIDE_HUD_COMPONENT_THIS_FRAME(CASH_CHANGE)

                if (_vehicleSearchInputPending) ProcessVehicleSearchInput();

                Ped ped = Game.Player.Character;
                ProcessPendingVehicleSpawn(ped);
                if (ped == null || ped.Handle == 0) return;

                ProcessPendingWaypointTeleport(ped);
                ProcessDestroyedTrainerVehicles(ped);

                if (!_originalModelCaptured)
                {
                    _originalModelHash = Function.Call<uint>(Hash.GET_ENTITY_MODEL, ped.Handle);
                    _originalModelCaptured = true;
                }

                ProcessPendingSkinStateRestore();
                ProcessPendingVehicleDeletion(ped);
                ProcessBodyguardFollowing(ped);
                ApplyPlayerSettings(ped);
                ApplyLegacyPlayerEffects(ped);
                ApplyVehicleSettings(ped);
                ApplyLegacyVehicleEffects(ped);
                ApplyWorldSettings();
                if (_settings.Speedometer) DrawSpeedometer(ped);

                // Grant automatically once per script session. Do not re-grant on every
                // ped/model transition because missions may deliberately replace equipment.
                if (_settings.AutoGiveWeapons && !_autoLoadoutGranted)
                {
                    GiveFullWeaponLoadout(ped);
                    _autoLoadoutGranted = true;
                    Notify("Full weapon loadout delivered.");
                }

                if (_menuOpen && !_vehicleSearchInputPending) DrawMenu();
            }
            catch (Exception ex)
            {
                LogException("Tick", ex);
                NotifyError("Tick");
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                // F11 is the only menu hotkey. F10 is intentionally not registered.
                if (e.KeyCode == Keys.F11 && !e.Shift && !e.Control && !e.Alt)
                {
                    _menuOpen = !_menuOpen;
                    if (!_menuOpen) _vehicleSearchInputPending = false;
                    if (_menuOpen)
                    {
                        _currentPage = "Main";
                        _pageStack.Clear();
                        _selectedIndex = 0;
                        _scrollOffset = 0;
                    }
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    return;
                }

                if (!_menuOpen) return;

                // Consume menu keys so they are not also processed by the game.
                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Enter ||
                    e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.Back || e.KeyCode == Keys.Escape)
                {
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }

                if (e.KeyCode == Keys.Escape)
                {
                    // ESC always closes the trainer. It never opens the pause/map screen.
                    _menuOpen = false;
                    _vehicleSearchInputPending = false;
                    _suppressPauseControlsFrames = 12;
                    _pageStack.Clear();
                    // The actual DISABLE_CONTROL_ACTION calls are repeated at the start
                    // of the next script tick, where GTA requires them to run.
                    BlockMenuGameControls();
                    return;
                }

                List<MenuEntry> entries = GetCurrentEntries();
                if (entries.Count == 0) return;

                if (e.KeyCode == Keys.Up)
                {
                    _selectedIndex = (_selectedIndex - 1 + entries.Count) % entries.Count;
                    KeepSelectionVisible(entries.Count);
                    return;
                }
                if (e.KeyCode == Keys.Down)
                {
                    _selectedIndex = (_selectedIndex + 1) % entries.Count;
                    KeepSelectionVisible(entries.Count);
                    return;
                }
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.NumPad5)
                {
                    MenuEntry selected = entries[_selectedIndex];
                    if (!String.IsNullOrEmpty(selected.ChildPage))
                    {
                        _pageStack.Push(_currentPage);
                        _currentPage = selected.ChildPage;
                        _selectedIndex = 0;
                        _scrollOffset = 0;
                    }
                    else if (selected.Action != null)
                    {
                        selected.Action();
                    }
                    return;
                }
                if (e.KeyCode == Keys.Back)
                {
                    if (_pageStack.Count > 0)
                    {
                        _currentPage = _pageStack.Pop();
                        _selectedIndex = 0;
                        _scrollOffset = 0;
                    }
                    else
                    {
                        _menuOpen = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogException("KeyDown", ex);
                NotifyError("Menu action");
            }
        }

        private void BlockMenuGameControls()
        {
            // Control 200 is INPUT_FRONTEND_PAUSE (ESC). Block pause/menu controls
            // in all input groups because GTA may read the pause input from a
            // different group than the one used by the trainer's menu navigation.
            int[] controls = new int[] { 27, 172, 173, 174, 175, 176, 177, 178, 199, 200, 202 };
            for (int group = 0; group <= 2; group++)
            {
                for (int i = 0; i < controls.Length; i++)
                    Function.Call((Hash)0xFE99B66D079CF6BCUL, group, controls[i], true);
            }
        }

        private void OnAborted(object sender, EventArgs e)
        {
            _aborted = true;
            try
            {
                Ped ped = Game.Player.Character;
                if (ped != null && ped.Handle != 0)
                {
                    Function.Call(Hash.SET_ENTITY_INVINCIBLE, ped.Handle, false);
                    Function.Call((Hash)0xEA1C610A04DB6BBBUL, ped.Handle, true, false);
                    Function.Call((Hash)0x1A9205C1B9EE827FUL, ped.Handle, true, true);
                    Function.Call((Hash)0xB128377056A54E2AUL, ped.Handle, true);
                    Function.Call((Hash)0xCE07B9F7817AADA3UL, Game.Player, 1.0f);
                    Function.Call((Hash)0x18F621F7A5B1F85DUL, false);
                    Function.Call((Hash)0x7E08924259E08CE0UL, false);
                    Function.Call(Hash.SET_PED_MAX_TIME_UNDERWATER, ped.Handle, 10.0f);
                    DisableInfiniteAmmoForCatalog(ped);
                    Function.Call(Hash.SET_POLICE_IGNORE_PLAYER, Game.Player, false);
                    Function.Call((Hash)0xB128377056A54E2AUL, ped.Handle, true);
                    Function.Call((Hash)0xEA1C610A04DB6BBBUL, ped.Handle, true, false);
                }
                Function.Call((Hash)0x18F621F7A5B1F85DUL, false);
                Function.Call((Hash)0x7E08924259E08CE0UL, false);
                CancelPendingVehicleSpawn();
                DismissAllBodyguards();
                if (_lastProtectedVehicleHandle != 0) RestoreVehicleProtection(_lastProtectedVehicleHandle);
                if (_clockPauseWasSet)
                {
                    Function.Call(Hash.PAUSE_CLOCK, false);
                    _clockPauseWasSet = false;
                }
                if (_weatherWasLocked)
                {
                    Function.Call(Hash.CLEAR_WEATHER_TYPE_PERSIST);
                    Function.Call(Hash.CLEAR_OVERRIDE_WEATHER);
                    _weatherWasLocked = false;
                }
                Function.Call(Hash.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER, Game.Player, 1.0f);
                Function.Call(Hash.SET_SWIM_MULTIPLIER_FOR_PLAYER, Game.Player, 1.0f);
                Log("Script aborted/unloaded; temporary protections and pending operations were cleaned up.");
            }
            catch (Exception ex)
            {
                LogException("Abort cleanup", ex);
            }
            finally
            {
                AppDomain.CurrentDomain.UnhandledException -= OnDomainUnhandledException;
                AppDomain.CurrentDomain.ProcessExit -= OnDomainProcessExit;
            }
        }

        private void ApplyPlayerSettings(Ped ped)
        {
            Function.Call(Hash.SET_ENTITY_INVINCIBLE, ped.Handle, _settings.GodMode);
            Function.Call(Hash.SET_PED_INFINITE_AMMO_CLIP, ped.Handle, _settings.NoReload);
            Function.Call((Hash)0xEA1C610A04DB6BBBUL, ped.Handle, !_settings.Invisible, false);
            Function.Call((Hash)0xB128377056A54E2AUL, ped.Handle, !_settings.NoRagdoll);
            // This is a per-frame native. Calling the wrong hash here can destabilize the game.
            if (_settings.ExplosiveAmmo) Function.Call((Hash)0xA66C71C98D5F2CFBUL, Game.Player);
            if (_settings.FireAmmo) Function.Call((Hash)0x11879CDD803D30F4UL, Game.Player);
            Function.Call((Hash)0xCE07B9F7817AADA3UL, Game.Player, _settings.SuperDamage ? 10.0f : 1.0f);
            Function.Call(Hash.SET_PED_MAX_TIME_UNDERWATER, ped.Handle, _settings.UnlimitedOxygen ? 1000.0f : 10.0f);
            Function.Call(Hash.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER, Game.Player, _settings.FastRun ? 1.49f : 1.0f);
            Function.Call(Hash.SET_SWIM_MULTIPLIER_FOR_PLAYER, Game.Player, _settings.FastSwim ? 1.49f : 1.0f);

            if (_settings.InfiniteStamina)
                Function.Call(Hash.RESET_PLAYER_STAMINA, Game.Player);

            if (_settings.SuperJump)
                Function.Call(Hash.SET_SUPER_JUMP_THIS_FRAME, Game.Player);

            if (_settings.NeverWanted)
            {
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, Game.Player, 0, false);
                Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, Game.Player, false);
                Function.Call(Hash.SET_POLICE_IGNORE_PLAYER, Game.Player, true);
            }
            else
            {
                Function.Call(Hash.SET_POLICE_IGNORE_PLAYER, Game.Player, _settings.CopsIgnore);
            }

            if (_settings.InfiniteAmmo)
            {
                uint weaponHash = Function.Call<uint>(Hash.GET_SELECTED_PED_WEAPON, ped.Handle);
                Function.Call(Hash.SET_PED_INFINITE_AMMO, ped.Handle, true, weaponHash);
                _infiniteAmmoWasApplied = true;
            }
            else if (_infiniteAmmoWasApplied)
            {
                DisableInfiniteAmmoForCatalog(ped);
                _infiniteAmmoWasApplied = false;
            }
        }

        private void ApplyVehicleSettings(Ped ped)
        {
            Vehicle vehicle = ped != null && ped.IsInVehicle() ? ped.CurrentVehicle : null;
            int currentHandle = vehicle == null ? 0 : vehicle.Handle;

            if (_lastProtectedVehicleHandle != 0 && _lastProtectedVehicleHandle != currentHandle)
            {
                RestoreVehicleProtection(_lastProtectedVehicleHandle);
                _lastProtectedVehicleHandle = 0;
            }

            if (currentHandle == 0) return;

            bool godMode = _settings.VehicleGodMode;
            bool protectWheels = godMode || _settings.BulletproofTires;

            Function.Call(Hash.SET_ENTITY_INVINCIBLE, currentHandle, godMode);
            Function.Call((Hash)0xFAEE099C6F890BB8UL, currentHandle,
                godMode, godMode, godMode, godMode, godMode, godMode, godMode, godMode); // SET_ENTITY_PROOFS
            Function.Call((Hash)0x1760FFA8AB074D66UL, currentHandle, !godMode); // SET_ENTITY_CAN_BE_DAMAGED
            Function.Call(Hash.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED, currentHandle, !godMode);
            Function.Call((Hash)0x3E8C8727991A8A0BUL, currentHandle, godMode); // SET_VEHICLE_STRONG
            Function.Call((Hash)0x71B0892EC081D60AUL, currentHandle, !godMode); // SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE
            Function.Call((Hash)0xD565F438137F0E10UL, currentHandle, !godMode); // SET_VEHICLE_EXPLODES_ON_EXPLOSION_DAMAGE_AT_ZERO_BODY_HEALTH
            Function.Call(Hash.SET_VEHICLE_TYRES_CAN_BURST, currentHandle, !protectWheels);
            Function.Call(Hash.SET_VEHICLE_WHEELS_CAN_BREAK, currentHandle, !protectWheels);

            _lastProtectedVehicleHandle = protectWheels || godMode ? currentHandle : 0;
        }

        private void RestoreVehicleProtection(int vehicleHandle)
        {
            if (vehicleHandle == 0) return;
            try
            {
                if (!Function.Call<bool>((Hash)0x7239B21A38F536BAUL, vehicleHandle)) return; // DOES_ENTITY_EXIST
                Function.Call(Hash.SET_ENTITY_INVINCIBLE, vehicleHandle, false);
                Function.Call((Hash)0xFAEE099C6F890BB8UL, vehicleHandle,
                    false, false, false, false, false, false, false, false); // SET_ENTITY_PROOFS
                Function.Call((Hash)0x1760FFA8AB074D66UL, vehicleHandle, true); // SET_ENTITY_CAN_BE_DAMAGED
                Function.Call(Hash.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED, vehicleHandle, true);
                Function.Call((Hash)0x3E8C8727991A8A0BUL, vehicleHandle, false); // SET_VEHICLE_STRONG
                Function.Call((Hash)0x71B0892EC081D60AUL, vehicleHandle, true);
                Function.Call((Hash)0xD565F438137F0E10UL, vehicleHandle, true);
                Function.Call(Hash.SET_VEHICLE_TYRES_CAN_BURST, vehicleHandle, true);
                Function.Call(Hash.SET_VEHICLE_WHEELS_CAN_BREAK, vehicleHandle, true);
            }
            catch (Exception ex)
            {
                LogException("RestoreVehicleProtection", ex);
            }
        }

        private void DisableInfiniteAmmoForCatalog(Ped ped)
        {
            for (int i = 0; i < _weaponNames.Length; i++)
            {
                uint weaponHash = GetHash(_weaponNames[i]);
                if (weaponHash != 0 && Function.Call<bool>(Hash.IS_WEAPON_VALID, weaponHash))
                    Function.Call(Hash.SET_PED_INFINITE_AMMO, ped.Handle, false, weaponHash);
            }
        }

        private void ApplyWorldSettings()
        {
            if (_settings.FreezeTime)
            {
                Function.Call(Hash.PAUSE_CLOCK, true);
                _clockPauseWasSet = true;
            }
            else if (_clockPauseWasSet)
            {
                Function.Call(Hash.PAUSE_CLOCK, false);
                _clockPauseWasSet = false;
            }

            if (_settings.LockWeather)
            {
                int now = Environment.TickCount;
                if (!_weatherWasLocked || unchecked(now - _lastWeatherApplyTick) > 1500)
                {
                    Function.Call(Hash.SET_WEATHER_TYPE_NOW_PERSIST, _settings.Weather);
                    _lastWeatherApplyTick = now;
                    _weatherWasLocked = true;
                }
            }
            else if (_weatherWasLocked)
            {
                Function.Call(Hash.CLEAR_WEATHER_TYPE_PERSIST);
                Function.Call(Hash.CLEAR_OVERRIDE_WEATHER);
                _weatherWasLocked = false;
            }
        }

        private void BuildMenus()
        {
            List<MenuEntry> main = NewPage("Main");
            main.Add(PageEntry("Player", "Player", "Player options from Extended and legacy 1.6."));
            main.Add(PageEntry("Weapons", "Weapons", "Weapon inventory, ammo and combat effects."));
            main.Add(PageEntry("Transport", "Transport", "Vehicle spawning, protection, tuning and customization."));
            main.Add(PageEntry("Powers & Vision", "Powers", "No-clip and vision modes."));
            main.Add(PageEntry("Bodyguards", "Bodyguards", "Spawn and dismiss armed companions."));
            main.Add(PageEntry("Animations", "Animations", "Scenario animations."));
            main.Add(PageEntry("Teleport", "Teleport", "Waypoint and landmark teleportation."));
            main.Add(PageEntry("Saved Locations", "Locations", "Save and revisit your own Story Mode locations."));
            main.Add(PageEntry("World", "World", "Weather, time and local cleanup."));
            main.Add(PageEntry("Settings", "Settings", "Save and reload trainer settings."));
            main.Add(ActionEntry("Close menu", "Close", null, delegate { _menuOpen = false; }));

            List<MenuEntry> player = NewPage("Player");
            player.Add(ToggleEntry("God Mode", "GodMode", delegate { return _settings.GodMode; }, delegate(bool v) { _settings.GodMode = v; }));
            player.Add(ToggleEntry("Never Wanted", "NeverWanted", delegate { return _settings.NeverWanted; }, delegate(bool v) { _settings.NeverWanted = v; }));
            player.Add(ToggleEntry("Police Ignore Player", "CopsIgnore", delegate { return _settings.CopsIgnore; }, delegate(bool v) { _settings.CopsIgnore = v; }));
            player.Add(ToggleEntry("Invisibility", "Invisible", delegate { return _settings.Invisible; }, delegate(bool v) { _settings.Invisible = v; }));
            player.Add(ToggleEntry("No Ragdoll", "NoRagdoll", delegate { return _settings.NoRagdoll; }, delegate(bool v) { _settings.NoRagdoll = v; }));
            player.Add(ToggleEntry("Infinite Stamina", "InfiniteStamina", delegate { return _settings.InfiniteStamina; }, delegate(bool v) { _settings.InfiniteStamina = v; }));
            player.Add(ToggleEntry("Unlimited Oxygen", "UnlimitedOxygen", delegate { return _settings.UnlimitedOxygen; }, delegate(bool v) { _settings.UnlimitedOxygen = v; }));
            player.Add(ToggleEntry("Fast Run", "FastRun", delegate { return _settings.FastRun; }, delegate(bool v) { _settings.FastRun = v; }));
            player.Add(ToggleEntry("Fast Swim", "FastSwim", delegate { return _settings.FastSwim; }, delegate(bool v) { _settings.FastSwim = v; }));
            player.Add(ToggleEntry("Super Jump", "SuperJump", delegate { return _settings.SuperJump; }, delegate(bool v) { _settings.SuperJump = v; }));
            player.Add(PageEntry("Money", "Money", "Add Story Mode cash to the currently controlled protagonist."));
            player.Add(ActionEntry("Heal + full armour", "Heal", "Restore health and armour.", HealPlayer));
            player.Add(ActionEntry("Clear wanted level", "Wanted", "Remove current wanted stars.", ClearWantedLevel));
            player.Add(ActionEntry("Wanted level: 1 star", "Wanted1", null, delegate { SetWantedLevel(1); }));
            player.Add(ActionEntry("Wanted level: 3 stars", "Wanted3", null, delegate { SetWantedLevel(3); }));
            player.Add(ActionEntry("Wanted level: 5 stars", "Wanted5", null, delegate { SetWantedLevel(5); }));
            player.Add(ActionEntry("Clean clothes & blood", "Clean", null, CleanPlayer));
            player.Add(ActionEntry("Suicide", "Suicide", "Kills the current player character.", SuicidePlayer));
            player.Add(BackEntry());

            List<MenuEntry> money = NewPage("Money");
            money.Add(ActionEntry("Add $100,000", "Money100K", null, delegate { AddStoryModeMoney(100000); }));
            money.Add(ActionEntry("Add $1,000,000", "Money1M", null, delegate { AddStoryModeMoney(1000000); }));
            money.Add(ActionEntry("Add $10,000,000", "Money10M", null, delegate { AddStoryModeMoney(10000000); }));
            money.Add(ActionEntry("Add $100,000,000", "Money100M", null, delegate { AddStoryModeMoney(100000000); }));
            money.Add(ActionEntry("Add $1,000,000,000", "Money1B", null, delegate { AddStoryModeMoney(1000000000); }));
            money.Add(ActionEntry("Set cash to maximum ($2.147B)", "MoneyMax", "Sets current protagonist cash to the signed 32-bit limit.", delegate { SetStoryModeMoney(StoryCashLimit); }));
            money.Add(BackEntry());

            List<MenuEntry> weapons = NewPage("Weapons");
            weapons.Add(ToggleEntry("Infinite Ammo", "InfiniteAmmo", delegate { return _settings.InfiniteAmmo; }, delegate(bool v) { _settings.InfiniteAmmo = v; }));
            weapons.Add(ToggleEntry("No Reload", "NoReload", delegate { return _settings.NoReload; }, delegate(bool v) { _settings.NoReload = v; }));
            weapons.Add(ToggleEntry("Auto Give Weapons", "AutoGiveWeapons", delegate { return _settings.AutoGiveWeapons; }, delegate(bool v) { _settings.AutoGiveWeapons = v; if (v) _autoLoadoutGranted = false; }));
            weapons.Add(ToggleEntry("Explosive Ammo", "ExplosiveAmmo", delegate { return _settings.ExplosiveAmmo; }, delegate(bool v) { _settings.ExplosiveAmmo = v; }));
            weapons.Add(ToggleEntry("Incendiary Ammo", "FireAmmo", delegate { return _settings.FireAmmo; }, delegate(bool v) { _settings.FireAmmo = v; }));
            weapons.Add(ToggleEntry("Super Damage", "SuperDamage", delegate { return _settings.SuperDamage; }, delegate(bool v) { _settings.SuperDamage = v; }));
            weapons.Add(ActionEntry("Give full weapon arsenal", "GiveWeapons", "Give all weapons supported by this game build.", GiveFullWeaponLoadoutToPlayer));
            weapons.Add(ActionEntry("Apply premium weapon finish", "WeaponFinish", "Apply available tint and compatible attachments.", ApplyWeaponFinishToCurrentLoadout));
            weapons.Add(ActionEntry("Remove all weapons", "RemoveWeapons", null, RemoveAllWeapons));
            weapons.Add(BackEntry());

            List<MenuEntry> transport = NewPage("Transport");
            transport.Add(PageEntry("Vehicle Spawner", "VehicleSpawner", "Search and spawn the complete local vehicle database."));
            transport.Add(ActionEntry("Search by name / Model ID", "VehicleSearch", "Search the external vehicle database by display name, model code or hash.", OpenVehicleSearchKeyboard));
            transport.Add(PageEntry("Add-On Vehicles", "Addons", "Browse entries from the preserved addons.json file."));
            transport.Add(ToggleEntry("Vehicle God Mode", "VehicleGodMode", delegate { return _settings.VehicleGodMode; }, delegate(bool v) { _settings.VehicleGodMode = v; }));
            transport.Add(ToggleEntry("Bulletproof Tires", "BulletproofTires", delegate { return _settings.BulletproofTires; }, delegate(bool v) { _settings.BulletproofTires = v; }));
            transport.Add(ToggleEntry("Nitro (hold SHIFT)", "Nitro", delegate { return _settings.Nitro; }, delegate(bool v) { _settings.Nitro = v; }));
            transport.Add(ToggleEntry("Drift Mode", "DriftMode", delegate { return _settings.DriftMode; }, delegate(bool v) { _settings.DriftMode = v; }));
            transport.Add(ToggleEntry("Speedometer", "Speedometer", delegate { return _settings.Speedometer; }, delegate(bool v) { _settings.Speedometer = v; }));
            transport.Add(ToggleEntry("Horn Jump", "HornJump", delegate { return _settings.HornJump; }, delegate(bool v) { _settings.HornJump = v; }));
            transport.Add(ActionEntry("Max Tuning (performance + appearance)", "MaxTuning", null, MaxTuneVehicle));
            transport.Add(ActionEntry("Neon underglow ON", "NeonOn", null, delegate { SetVehicleNeons(true); }));
            transport.Add(ActionEntry("Neon underglow OFF", "NeonOff", null, delegate { SetVehicleNeons(false); }));
            transport.Add(ActionEntry("Limo window tint", "Tint", null, SetVehicleTint));
            transport.Add(ActionEntry("Matte black paint", "BlackPaint", null, delegate { SetVehicleColours(0, 0); }));
            transport.Add(ActionEntry("Black / red paint", "RedPaint", null, delegate { SetVehicleColours(0, 27); }));
            transport.Add(ActionEntry("Custom plate: YNIX", "Plate", null, delegate { SetVehiclePlate("YNIX"); }));
            transport.Add(ActionEntry("Repair & wash vehicle", "Repair", "Manual action only; no automatic repair.", RepairCurrentVehicle));
            transport.Add(ActionEntry("Flip vehicle upright", "Flip", null, FlipVehicle));
            transport.Add(ActionEntry("Open all doors", "OpenDoors", null, delegate { SetAllVehicleDoors(true); }));
            transport.Add(ActionEntry("Close all doors", "CloseDoors", null, delegate { SetAllVehicleDoors(false); }));
            transport.Add(ActionEntry("Start waypoint autopilot", "Autopilot", null, StartAutopilot));
            transport.Add(ActionEntry("Stop autopilot", "StopAutopilot", null, StopAutopilot));
            transport.Add(ActionEntry("Delete current vehicle", "DeleteVehicle", "Deletes the vehicle you are currently driving.", DeleteCurrentVehicle));
            transport.Add(ActionEntry("Switch speed unit KM/H / MPH", "SpeedUnit", null, ToggleSpeedUnit));
            transport.Add(ActionEntry("Reload vehicle database", "ReloadVehicleDatabase", null, delegate
            {
                bool catalogLoaded = LoadVehicleCatalog();
                bool addonsLoaded = LoadAddonVehicles();
                RebuildVehicleSpawnerMenu();
                if (catalogLoaded || addonsLoaded)
                    Notify("Vehicle lists reloaded: " + GetCombinedVehicleList().Count + " unique models.");
                else
                    Notify("Vehicle database reload failed. Previous valid list was retained; check scripts\\YnixTrainer_Logs\\errors.log.");
            }));
            transport.Add(BackEntry());

            List<MenuEntry> vehicleSpawner = NewPage("VehicleSpawner");
            vehicleSpawner.Add(new MenuEntry("Loading vehicle catalog...", "", null, null, null));
            vehicleSpawner.Add(BackEntry());

            List<MenuEntry> powers = NewPage("Powers");
            powers.Add(ToggleEntry("No-Clip / Fly Mode", "NoClip", delegate { return _settings.NoClip; }, delegate(bool v) { _settings.NoClip = v; if (!v) RestoreNoClip(); }));
            powers.Add(ToggleEntry("Night Vision", "NightVision", delegate { return _settings.NightVision; }, delegate(bool v) { _settings.NightVision = v; }));
            powers.Add(ToggleEntry("Thermal Vision", "ThermalVision", delegate { return _settings.ThermalVision; }, delegate(bool v) { _settings.ThermalVision = v; }));
            powers.Add(BackEntry());

            List<MenuEntry> bodyguards = NewPage("Bodyguards");
            bodyguards.Add(ActionEntry("Spawn SWAT bodyguard", "SpawnSwat", null, delegate { SpawnBodyguard("s_m_y_swat_01"); }));
            bodyguards.Add(ActionEntry("Spawn military bodyguard", "SpawnMilitary", null, delegate { SpawnBodyguard("s_m_y_marine_01"); }));
            bodyguards.Add(ActionEntry("Spawn agent bodyguard", "SpawnAgent", null, delegate { SpawnBodyguard("s_m_m_fibsec_01"); }));
            bodyguards.Add(ActionEntry("Dismiss all bodyguards", "DismissGuards", null, DismissAllBodyguards));
            bodyguards.Add(BackEntry());

            List<MenuEntry> animations = NewPage("Animations");
            animations.Add(ActionEntry("Stop animation", "StopAnim", null, StopPlayerAnimation));
            animations.Add(ActionEntry("Smoke cigarette", "Smoke", null, delegate { StartPlayerScenario("WORLD_HUMAN_SMOKING"); }));
            animations.Add(ActionEntry("Drink", "Drink", null, delegate { StartPlayerScenario("WORLD_HUMAN_DRINKING"); }));
            animations.Add(ActionEntry("Dance", "Dance", null, delegate { StartPlayerScenario("WORLD_HUMAN_PARTYING"); }));
            animations.Add(ActionEntry("Sit", "Sit", null, delegate { StartPlayerScenario("WORLD_HUMAN_PICNIC"); }));
            animations.Add(ActionEntry("Push-ups", "Pushups", null, delegate { StartPlayerScenario("WORLD_HUMAN_PUSH_UPS"); }));
            animations.Add(BackEntry());

            List<MenuEntry> teleport = NewPage("Teleport");
            teleport.Add(ActionEntry("Teleport to waypoint", "Waypoint", null, TeleportToWaypoint));
            teleport.Add(ActionEntry("Teleport 3m forward", "Forward", null, TeleportForward));
            teleport.Add(ActionEntry("Maze Bank roof", "MazeBank", null, delegate { TeleportTo( -75.01f, -818.91f, 326.18f); }));
            teleport.Add(ActionEntry("Vinewood Sign", "Vinewood", null, delegate { TeleportTo(707.3f, 1197.2f, 348.5f); }));
            teleport.Add(ActionEntry("Mount Chiliad", "Chiliad", null, delegate { TeleportTo(501.2f, 5604.5f, 797.9f); }));
            teleport.Add(ActionEntry("LS International Airport", "Airport", null, delegate { TeleportTo(-1034.6f, -2733.6f, 20.1f); }));
            teleport.Add(ActionEntry("Del Perro Pier", "Pier", null, delegate { TeleportTo(-1850.1f, -1231.8f, 13.0f); }));
            teleport.Add(ActionEntry("Fort Zancudo", "Fort", null, delegate { TeleportTo(-2047.4f, 3132.1f, 32.8f); }));
            teleport.Add(ActionEntry("Bolingbroke Prison", "Prison", null, delegate { TeleportTo(1691.5f, 2565.9f, 45.6f); }));
            teleport.Add(ActionEntry("Sandy Shores Airfield", "Sandy", null, delegate { TeleportTo(1747.8f, 3273.7f, 41.1f); }));
            teleport.Add(ActionEntry("Humane Labs", "Humane", null, delegate { TeleportTo(3540.0f, 3675.0f, 28.1f); }));
            teleport.Add(ActionEntry("Galileo Observatory", "Galileo", null, delegate { TeleportTo(-438.7f, 1075.0f, 327.7f); }));
            teleport.Add(BackEntry());

            List<MenuEntry> world = NewPage("World");
            world.Add(ToggleEntry("Freeze Time", "FreezeTime", delegate { return _settings.FreezeTime; }, delegate(bool v) { _settings.FreezeTime = v; }));
            world.Add(ToggleEntry("Lock Weather", "LockWeather", delegate { return _settings.LockWeather; }, delegate(bool v) { _settings.LockWeather = v; }));
            world.Add(ActionEntry("Extra Sunny", "Sunny", null, delegate { SetWeather("EXTRASUNNY"); }));
            world.Add(ActionEntry("Clear", "Clear", null, delegate { SetWeather("CLEAR"); }));
            world.Add(ActionEntry("Clouds", "Clouds", null, delegate { SetWeather("CLOUDS"); }));
            world.Add(ActionEntry("Rain", "Rain", null, delegate { SetWeather("RAIN"); }));
            world.Add(ActionEntry("Thunderstorm", "Thunder", null, delegate { SetWeather("THUNDER"); }));
            world.Add(ActionEntry("Snow", "Snow", null, delegate { SetWeather("SNOW"); }));
            world.Add(ActionEntry("Blizzard", "Blizzard", null, delegate { SetWeather("BLIZZARD"); }));
            world.Add(ActionEntry("Halloween", "Halloween", null, delegate { SetWeather("HALLOWEEN"); }));
            world.Add(ActionEntry("Time: Morning", "Morning", null, delegate { SetClockTime(6, 0); }));
            world.Add(ActionEntry("Time: Noon", "Noon", null, delegate { SetClockTime(12, 0); }));
            world.Add(ActionEntry("Time: Evening", "Evening", null, delegate { SetClockTime(18, 0); }));
            world.Add(ActionEntry("Time: Midnight", "Midnight", null, delegate { SetClockTime(0, 0); }));
            world.Add(ActionEntry("Clear nearby traffic & peds", "ClearArea", "Removes non-player traffic and pedestrians nearby.", ClearNearbyArea));
            world.Add(BackEntry());

            List<MenuEntry> addons = NewPage("Addons");
            addons.Add(new MenuEntry("Selected add-on", "Current selection", delegate { return GetSelectedAddonLabel(); }, null, null));
            addons.Add(ActionEntry("Previous add-on", "PreviousAddon", null, PreviousAddon));
            addons.Add(ActionEntry("Next add-on", "NextAddon", null, NextAddon));
            addons.Add(ActionEntry("Spawn selected add-on", "SpawnAddon", null, SpawnSelectedAddon));
            addons.Add(ActionEntry("Reload addons.json", "ReloadAddons", null, delegate
            {
                if (LoadAddonVehicles()) Notify("Add-on list reloaded.");
            }));
            addons.Add(BackEntry());

            List<MenuEntry> settings = NewPage("Settings");
            settings.Add(PageEntry("Interface customization", "Interface", "Position, width, scale, font, colors and transparency."));
            settings.Add(ActionEntry("Save settings", "Save", null, delegate { SaveSettings(); Notify("Settings saved."); }));
            settings.Add(ActionEntry("Reload settings", "Reload", null, delegate { LoadSettings(); Notify("Settings reloaded."); }));
            settings.Add(ActionEntry("Reload add-on list", "ReloadAddons", null, delegate
            {
                if (LoadAddonVehicles()) Notify("Add-on list reloaded.");
            }));
            settings.Add(BackEntry());

            List<MenuEntry> interfacePage = NewPage("Interface");
            interfacePage.Add(ValueActionEntry("Move left", "Shift the menu toward the left edge.", delegate { return _settings.MenuX.ToString("0.000", CultureInfo.InvariantCulture); }, delegate { AdjustMenuPosition(-0.02f, 0.0f); }));
            interfacePage.Add(ValueActionEntry("Move right", "Shift the menu toward the right edge.", delegate { return _settings.MenuX.ToString("0.000", CultureInfo.InvariantCulture); }, delegate { AdjustMenuPosition(0.02f, 0.0f); }));
            interfacePage.Add(ValueActionEntry("Move up", "Shift the menu upward.", delegate { return _settings.MenuY.ToString("0.000", CultureInfo.InvariantCulture); }, delegate { AdjustMenuPosition(0.0f, -0.02f); }));
            interfacePage.Add(ValueActionEntry("Move down", "Shift the menu downward.", delegate { return _settings.MenuY.ToString("0.000", CultureInfo.InvariantCulture); }, delegate { AdjustMenuPosition(0.0f, 0.02f); }));
            interfacePage.Add(ValueActionEntry("Menu width -", "Make the menu narrower.", delegate { return _settings.MenuWidth.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuWidth(-0.01f); }));
            interfacePage.Add(ValueActionEntry("Menu width +", "Make the menu wider.", delegate { return _settings.MenuWidth.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuWidth(0.01f); }));
            interfacePage.Add(ValueActionEntry("Menu scale -", "Reduce the overall menu size.", delegate { return _settings.MenuScale.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuScale(-0.05f); }));
            interfacePage.Add(ValueActionEntry("Menu scale +", "Increase the overall menu size.", delegate { return _settings.MenuScale.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuScale(0.05f); }));
            interfacePage.Add(ValueActionEntry("Font size -", "Reduce menu text size.", delegate { return _settings.MenuFontScale.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuFontScale(-0.05f); }));
            interfacePage.Add(ValueActionEntry("Font size +", "Increase menu text size.", delegate { return _settings.MenuFontScale.ToString("0.00", CultureInfo.InvariantCulture); }, delegate { ChangeMenuFontScale(0.05f); }));
            interfacePage.Add(ValueActionEntry("Font style", "Cycle through readable GTA font styles.", delegate { return GetMenuFontName(); }, CycleMenuFont));
            interfacePage.Add(ValueActionEntry("Color theme", "Cycle red, blue, purple, green and monochrome themes.", delegate { return GetMenuThemeName(); }, CycleMenuTheme));
            interfacePage.Add(ValueActionEntry("Background opacity -", "Make the menu background more transparent.", delegate { return _settings.MenuOpacity.ToString(CultureInfo.InvariantCulture); }, delegate { ChangeMenuOpacity(-15); }));
            interfacePage.Add(ValueActionEntry("Background opacity +", "Make the menu background less transparent.", delegate { return _settings.MenuOpacity.ToString(CultureInfo.InvariantCulture); }, delegate { ChangeMenuOpacity(15); }));
            interfacePage.Add(ValueActionEntry("Visible rows -", "Show fewer entries at once.", delegate { return _settings.MenuRows.ToString(CultureInfo.InvariantCulture); }, delegate { ChangeMenuRows(-1); }));
            interfacePage.Add(ValueActionEntry("Visible rows +", "Show more entries at once.", delegate { return _settings.MenuRows.ToString(CultureInfo.InvariantCulture); }, delegate { ChangeMenuRows(1); }));
            interfacePage.Add(ActionEntry("Reset interface settings", "ResetInterface", null, ResetMenuInterfaceSettings));
            interfacePage.Add(ActionEntry("Save interface settings", "SaveInterface", null, delegate { SaveSettings(); Notify("Interface settings saved."); }));
            interfacePage.Add(BackEntry());

            NewPage("Locations");
            RebuildFavoriteLocationsMenu();
        }

        private List<MenuEntry> NewPage(string name)
        {
            List<MenuEntry> list = new List<MenuEntry>();
            _pages[name] = list;
            return list;
        }

        private MenuEntry PageEntry(string title, string page, string description)
        {
            return new MenuEntry(title, description, null, page, null);
        }

        private MenuEntry BackEntry()
        {
            return ActionEntry("Back", "Back", "Return to the previous menu.", delegate
            {
                if (_pageStack.Count > 0) _currentPage = _pageStack.Pop();
                else _currentPage = "Main";
                _selectedIndex = 0;
                _scrollOffset = 0;
            });
        }

        private MenuEntry ActionEntry(string title, string key, string description, Action action)
        {
            Action safeAction = null;
            if (action != null)
            {
                safeAction = delegate
                {
                    try { action(); }
                    catch (Exception ex)
                    {
                        LogException("Action " + key, ex);
                        NotifyError(title);
                    }
                };
            }
            return new MenuEntry(title, description, null, null, safeAction);
        }

        private MenuEntry ValueActionEntry(string title, string description, Func<string> value, Action action)
        {
            Action safeAction = null;
            if (action != null)
            {
                safeAction = delegate
                {
                    try { action(); }
                    catch (Exception ex)
                    {
                        LogException("Interface setting " + title, ex);
                        NotifyError(title);
                    }
                };
            }
            return new MenuEntry(title, description, value, null, safeAction);
        }

        private MenuEntry ToggleEntry(string title, string key, Func<bool> getter, Action<bool> setter)
        {
            return new MenuEntry(title, key, delegate { return getter() ? "ON" : "OFF"; }, null, delegate
            {
                try
                {
                    bool newValue = !getter();
                    setter(newValue);
                    SaveSettings();
                }
                catch (Exception ex)
                {
                    LogException("Toggle " + key, ex);
                    NotifyError(title);
                }
            });
        }

        private List<MenuEntry> GetCurrentEntries()
        {
            if (String.IsNullOrEmpty(_currentPage) || !_pages.ContainsKey(_currentPage)) return new List<MenuEntry>();
            return _pages[_currentPage];
        }

        private void KeepSelectionVisible(int count)
        {
            if (_selectedIndex < _scrollOffset) _scrollOffset = _selectedIndex;
            if (_selectedIndex >= _scrollOffset + GetVisibleMenuRows()) _scrollOffset = _selectedIndex - GetVisibleMenuRows() + 1;
            if (_scrollOffset < 0) _scrollOffset = 0;
            if (_scrollOffset > Math.Max(0, count - GetVisibleMenuRows())) _scrollOffset = Math.Max(0, count - GetVisibleMenuRows());
        }

        private void LoadFavoriteLocations()
        {
            if (!File.Exists(_favoriteLocationsPath)) return;
            try
            {
                FileInfo info = new FileInfo(_favoriteLocationsPath);
                if (info.Length > 256 * 1024) throw new InvalidDataException("favorite_locations.json exceeds 256 KB.");
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = 256 * 1024;
                serializer.RecursionLimit = 8;
                List<FavoriteLocation> parsed = serializer.Deserialize<List<FavoriteLocation>>(File.ReadAllText(_favoriteLocationsPath));
                if (parsed == null) throw new InvalidDataException("Favorite locations root must be a JSON array.");

                _favoriteLocations.Clear();
                for (int i = 0; i < parsed.Count && _favoriteLocations.Count < 100; i++)
                {
                    FavoriteLocation item = parsed[i];
                    if (item == null || Single.IsNaN(item.x) || Single.IsInfinity(item.x) ||
                        Single.IsNaN(item.y) || Single.IsInfinity(item.y) ||
                        Single.IsNaN(item.z) || Single.IsInfinity(item.z)) continue;
                    if (item.x < -20000.0f || item.x > 20000.0f || item.y < -20000.0f || item.y > 20000.0f ||
                        item.z < -2000.0f || item.z > 10000.0f) continue;
                    string name = SanitizeMenuText(item.name, 48, "Saved location " + (_favoriteLocations.Count + 1).ToString("000"));
                    _favoriteLocations.Add(new FavoriteLocation { name = name, x = item.x, y = item.y, z = item.z });
                }
                Log("Loaded saved locations: " + _favoriteLocations.Count);
            }
            catch (Exception ex)
            {
                LogException("LoadFavoriteLocations", ex);
                Notify("Saved locations could not be loaded. The trainer will continue without them.");
            }
        }

        private void SaveFavoriteLocations()
        {
            try
            {
                Directory.CreateDirectory(_dataDirectory);
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                serializer.MaxJsonLength = 256 * 1024;
                string json = serializer.Serialize(_favoriteLocations);
                string temporaryPath = _favoriteLocationsPath + ".tmp";
                string backupPath = _favoriteLocationsPath + ".bak";
                File.WriteAllText(temporaryPath, json, System.Text.Encoding.UTF8);
                if (File.Exists(_favoriteLocationsPath))
                {
                    // File.Replace swaps the complete file and keeps the previous
                    // version as a backup if the process is interrupted.
                    if (File.Exists(backupPath)) File.Delete(backupPath);
                    File.Replace(temporaryPath, _favoriteLocationsPath, backupPath);
                }
                else
                {
                    File.Move(temporaryPath, _favoriteLocationsPath);
                }
                Log("Saved locations written: " + _favoriteLocations.Count);
            }
            catch (Exception ex)
            {
                LogException("SaveFavoriteLocations", ex);
                Notify("Could not save favorite locations. See log.");
            }
        }

        private void RebuildFavoriteLocationsMenu()
        {
            if (!_pages.ContainsKey("Locations")) return;
            List<MenuEntry> page = _pages["Locations"];
            page.Clear();
            page.Add(ActionEntry("Save current position", "SaveFavoriteLocation", "Save the current player position as a quick teleport destination.", SaveCurrentFavoriteLocation));
            if (_favoriteLocations.Count == 0)
            {
                page.Add(new MenuEntry("No saved locations", "Use Save current position to add one.", null, null, null));
            }
            else
            {
                for (int i = 0; i < _favoriteLocations.Count; i++)
                {
                    FavoriteLocation captured = _favoriteLocations[i];
                    string title = captured.name;
                    page.Add(ActionEntry("Go to: " + title, "GoFavorite" + i.ToString(CultureInfo.InvariantCulture),
                        "Teleport to saved coordinates.", delegate { TeleportToFavoriteLocation(captured); }));
                    page.Add(ActionEntry("Delete: " + title, "DeleteFavorite" + i.ToString(CultureInfo.InvariantCulture),
                        "Remove this saved location.", delegate { DeleteFavoriteLocation(captured); }));
                }
                page.Add(ActionEntry("Clear all saved locations", "ClearFavoriteLocations", null, ClearFavoriteLocations));
            }
            page.Add(BackEntry());
        }

        private void SaveCurrentFavoriteLocation()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0)
            {
                Notify("Player is not available.");
                return;
            }
            if (_favoriteLocations.Count >= 100)
            {
                Notify("Saved location limit reached (100).");
                return;
            }
            int sequence = 1;
            string name;
            do
            {
                name = "Saved location " + sequence.ToString("000", CultureInfo.InvariantCulture);
                sequence++;
            }
            while (_favoriteLocations.Any(delegate(FavoriteLocation item) { return String.Equals(item.name, name, StringComparison.OrdinalIgnoreCase); }) && sequence <= 101);

            Vector3 position = ped.Position;
            _favoriteLocations.Add(new FavoriteLocation { name = name, x = position.X, y = position.Y, z = position.Z });
            SaveFavoriteLocations();
            RebuildFavoriteLocationsMenu();
            Notify("Saved: " + name);
        }

        private void TeleportToFavoriteLocation(FavoriteLocation location)
        {
            if (location == null) return;
            TeleportTo(location.x, location.y, location.z + 1.0f);
        }

        private void DeleteFavoriteLocation(FavoriteLocation location)
        {
            if (location == null) return;
            _favoriteLocations.Remove(location);
            SaveFavoriteLocations();
            RebuildFavoriteLocationsMenu();
            Notify("Saved location deleted.");
            _selectedIndex = 0;
            _scrollOffset = 0;
        }

        private void ClearFavoriteLocations()
        {
            _favoriteLocations.Clear();
            SaveFavoriteLocations();
            RebuildFavoriteLocationsMenu();
            Notify("All saved locations cleared.");
            _selectedIndex = 0;
            _scrollOffset = 0;
        }

        private int GetVisibleMenuRows()
        {
            return ClampInt(_settings.MenuRows, 6, 12);
        }

        private static float ClampFloat(float value, float minimum, float maximum)
        {
            if (value < minimum) return minimum;
            if (value > maximum) return maximum;
            return value;
        }

        private static int ClampInt(int value, int minimum, int maximum)
        {
            if (value < minimum) return minimum;
            if (value > maximum) return maximum;
            return value;
        }

        private void SaveInterfaceAdjustment(string message)
        {
            SaveSettings();
            if (!String.IsNullOrEmpty(message)) Notify(message);
        }

        private float GetMaximumMenuX()
        {
            float width = ClampFloat(_settings.MenuWidth, 0.19f, 0.36f) * ClampFloat(_settings.MenuScale, 0.75f, 1.30f);
            return Math.Max(0.005f, 0.995f - width);
        }

        private float GetMaximumMenuY()
        {
            float scale = ClampFloat(_settings.MenuScale, 0.75f, 1.30f);
            float estimatedHeight = (0.015f + 0.080f + GetVisibleMenuRows() * 0.029f + 0.045f) * scale;
            return Math.Max(0.005f, 0.995f - estimatedHeight);
        }

        private void AdjustMenuPosition(float dx, float dy)
        {
            _settings.MenuX = ClampFloat(_settings.MenuX + dx, 0.005f, GetMaximumMenuX());
            _settings.MenuY = ClampFloat(_settings.MenuY + dy, 0.005f, GetMaximumMenuY());
            SaveInterfaceAdjustment("Menu position updated.");
        }

        private void ChangeMenuWidth(float delta)
        {
            _settings.MenuWidth = ClampFloat(_settings.MenuWidth + delta, 0.19f, 0.36f);
            _settings.MenuX = ClampFloat(_settings.MenuX, 0.005f, GetMaximumMenuX());
            SaveInterfaceAdjustment("Menu width updated.");
        }

        private void ChangeMenuScale(float delta)
        {
            _settings.MenuScale = ClampFloat(_settings.MenuScale + delta, 0.75f, 1.30f);
            _settings.MenuX = ClampFloat(_settings.MenuX, 0.005f, GetMaximumMenuX());
            _settings.MenuY = ClampFloat(_settings.MenuY, 0.005f, GetMaximumMenuY());
            SaveInterfaceAdjustment("Menu scale updated.");
        }

        private void ChangeMenuFontScale(float delta)
        {
            _settings.MenuFontScale = ClampFloat(_settings.MenuFontScale + delta, 0.70f, 1.40f);
            SaveInterfaceAdjustment("Menu font size updated.");
        }

        private void ChangeMenuOpacity(int delta)
        {
            _settings.MenuOpacity = ClampInt(_settings.MenuOpacity + delta, 100, 255);
            SaveInterfaceAdjustment("Menu opacity updated.");
        }

        private void ChangeMenuRows(int delta)
        {
            _settings.MenuRows = ClampInt(_settings.MenuRows + delta, 6, 12);
            _settings.MenuY = ClampFloat(_settings.MenuY, 0.005f, GetMaximumMenuY());
            KeepSelectionVisible(GetCurrentEntries().Count);
            SaveInterfaceAdjustment("Visible menu rows updated.");
        }

        private void CycleMenuFont()
        {
            _settings.MenuFontStyle = (_settings.MenuFontStyle + 1) % 4;
            SaveInterfaceAdjustment("Font: " + GetMenuFontName());
        }

        private void CycleMenuTheme()
        {
            _settings.MenuTheme = (_settings.MenuTheme + 1) % 5;
            SaveInterfaceAdjustment("Color theme: " + GetMenuThemeName());
        }

        private string GetMenuFontName()
        {
            string[] names = new string[] { "Standard", "Monospace", "Condensed", "Script" };
            return names[ClampInt(_settings.MenuFontStyle, 0, names.Length - 1)];
        }

        private string GetMenuThemeName()
        {
            string[] names = new string[] { "Red", "Blue", "Purple", "Green", "Monochrome" };
            return names[ClampInt(_settings.MenuTheme, 0, names.Length - 1)];
        }

        private void GetMenuThemeColor(out int red, out int green, out int blue)
        {
            switch (ClampInt(_settings.MenuTheme, 0, 4))
            {
                case 1: red = 35; green = 105; blue = 185; break;
                case 2: red = 115; green = 65; blue = 175; break;
                case 3: red = 35; green = 135; blue = 90; break;
                case 4: red = 125; green = 130; blue = 140; break;
                default: red = 135; green = 35; blue = 48; break;
            }
        }

        private void ResetMenuInterfaceSettings()
        {
            _settings.MenuX = 0.755f;
            _settings.MenuY = 0.006f;
            _settings.MenuWidth = 0.240f;
            _settings.MenuScale = 1.0f;
            _settings.MenuFontScale = 1.0f;
            _settings.MenuFontStyle = 0;
            _settings.MenuTheme = 0;
            _settings.MenuOpacity = 225;
            _settings.MenuRows = 9;
            _selectedIndex = 0;
            _scrollOffset = 0;
            SaveInterfaceAdjustment("Interface settings reset.");
        }

        private void DrawMenu()
        {
            List<MenuEntry> entries = GetCurrentEntries();
            if (entries.Count == 0) return;

            float scale = ClampFloat(_settings.MenuScale, 0.75f, 1.30f);
            float width = ClampFloat(_settings.MenuWidth, 0.19f, 0.36f) * scale;
            float x = ClampFloat(_settings.MenuX, 0.005f, 0.995f - width);
            float rowHeight = 0.029f * scale;
            int visible = Math.Min(GetVisibleMenuRows(), entries.Count);
            float headerHeight = 0.080f * scale;
            float footerHeight = 0.045f * scale;
            float height = 0.015f * scale + headerHeight + visible * rowHeight + footerHeight;
            float top = ClampFloat(_settings.MenuY, 0.005f, Math.Max(0.005f, 0.995f - height));
            float fontScale = ClampFloat(_settings.MenuFontScale, 0.70f, 1.40f);
            int alpha = ClampInt(_settings.MenuOpacity, 100, 255);
            int accentR, accentG, accentB;
            GetMenuThemeColor(out accentR, out accentG, out accentB);

            DrawRect(x + width / 2.0f, top + height / 2.0f, width, height, 8, 10, 14, alpha);
            DrawRect(x + width / 2.0f, top + 0.020f * scale, width, 0.040f * scale,
                accentR, accentG, accentB, 245);
            DrawMenuText(ProductName + "  v" + ProductVersion, x + 0.009f * scale, top + 0.006f * scale,
                0.27f * scale * fontScale, 245, 245, 245, 255);
            DrawMenuText(_currentPage, x + 0.009f * scale, top + 0.049f * scale,
                0.22f * scale * fontScale, 205, 210, 220, 255);

            for (int row = 0; row < visible; row++)
            {
                int itemIndex = _scrollOffset + row;
                if (itemIndex < 0 || itemIndex >= entries.Count) continue;
                MenuEntry item = entries[itemIndex];
                float y = top + headerHeight + row * rowHeight;
                bool selected = itemIndex == _selectedIndex;
                if (selected)
                {
                    DrawRect(x + width / 2.0f, y + 0.012f * scale, width - 0.010f * scale,
                        rowHeight - 0.002f * scale, accentR, accentG, accentB, 205);
                }

                string marker = selected ? "> " : "  ";
                string suffix = item.Value == null ? (item.ChildPage == null ? String.Empty : "  >") : "  [" + item.Value() + "]";
                DrawMenuText(marker + item.Title + suffix, x + 0.010f * scale, y + 0.003f * scale,
                    0.205f * scale * fontScale,
                    selected ? 255 : 215, selected ? 255 : 220, selected ? 255 : 230, 255);
            }

            string help = "ARROWS/ENTER  BACK: BACKSPACE  ESC/F11: CLOSE";
            DrawMenuText(help, x + 0.009f * scale, top + height - 0.030f * scale,
                0.135f * scale * fontScale, 170, 175, 185, 255);
        }

        private void DrawMenuText(string text, float x, float y, float scale, int r, int g, int b, int a)
        {
            int style = ClampInt(_settings.MenuFontStyle, 0, 3);
            int font = style == 1 ? 2 : (style == 2 ? 4 : (style == 3 ? 1 : 0));
            DrawTextWithFont(text, x, y, scale, r, g, b, a, font);
        }

        private void DrawText(string text, float x, float y, float scale, int r, int g, int b, int a)
        {
            DrawTextWithFont(text, x, y, scale, r, g, b, a, 0);
        }

        private void DrawTextWithFont(string text, float x, float y, float scale, int r, int g, int b, int a, int font)
        {
            Function.Call(Hash.SET_TEXT_FONT, font);
            Function.Call(Hash.SET_TEXT_SCALE, scale, scale);
            Function.Call(Hash.SET_TEXT_COLOUR, r, g, b, a);
            Function.Call(Hash.SET_TEXT_OUTLINE);
            Function.Call(Hash.SET_TEXT_CENTRE, false);
            Function.Call((Hash)0x25FBB336DF1804CBUL, "STRING");
            Function.Call((Hash)0x6C188BE134E074AAUL, text);
            Function.Call((Hash)0xCD015E5BB0D96A57UL, x, y, 0);
        }

        private void DrawRect(float x, float y, float width, float height, int r, int g, int b, int a)
        {
            Function.Call(Hash.DRAW_RECT, x, y, width, height, r, g, b, a);
        }

        private void Notify(string message)
        {
            try
            {
                Function.Call((Hash)0xB87A37EEB7FAA67DUL, "STRING");
                Function.Call((Hash)0x6C188BE134E074AAUL, message);
                Function.Call((Hash)0x9D77056A530643F6UL, 3000, true);
            }
            catch (Exception ex)
            {
                LogException("Notification", ex);
            }
        }

        private void ApplyLegacyPlayerEffects(Ped ped)
        {
            if (_settings.NoClip)
            {
                ApplyNoClipMovement(ped);
                _noClipWasActive = true;
            }
            else if (_noClipWasActive)
            {
                RestoreNoClip();
            }
            Function.Call((Hash)0x18F621F7A5B1F85DUL, _settings.NightVision);
            Function.Call((Hash)0x7E08924259E08CE0UL, _settings.ThermalVision);
        }

        private void ApplyNoClipMovement(Ped ped)
        {
            Function.Call((Hash)0x1A9205C1B9EE827FUL, ped.Handle, false, false);
            Vector3 forward = Function.Call<Vector3>(Hash.GET_ENTITY_FORWARD_VECTOR, ped.Handle);
            Vector3 right = new Vector3(forward.Y, -forward.X, 0.0f);
            Vector3 position = ped.Position;
            float speed = IsControlPressed(21) ? 0.75f : 0.28f;
            if (IsControlPressed(32)) position += forward * speed;
            if (IsControlPressed(33)) position -= forward * speed;
            if (IsControlPressed(34)) position -= right * speed;
            if (IsControlPressed(35)) position += right * speed;
            if (IsControlPressed(22)) position.Z += speed;
            if (IsControlPressed(36)) position.Z -= speed;
            Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, ped.Handle, position.X, position.Y, position.Z, false, false, false);
        }

        private bool IsControlPressed(int control)
        {
            return Function.Call<bool>((Hash)0xF3A21BCD95725A4AUL, 0, control);
        }

        private void RestoreNoClip()
        {
            try
            {
                Ped ped = Game.Player.Character;
                if (ped != null && ped.Handle != 0)
                    Function.Call((Hash)0x1A9205C1B9EE827FUL, ped.Handle, true, true);
                _noClipWasActive = false;
            }
            catch (Exception ex) { LogException("RestoreNoClip", ex); }
        }

        private void ApplyLegacyVehicleEffects(Ped ped)
        {
            if (!ped.IsInVehicle()) return;
            Vehicle vehicle = ped.CurrentVehicle;
            if (vehicle == null || vehicle.Handle == 0) return;
            int handle = vehicle.Handle;
            Function.Call((Hash)0x222FF6A823D122E2UL, handle, _settings.DriftMode);
            if (_settings.Nitro && IsControlPressed(21))
            {
                bool hasTrailer = Function.Call<bool>((Hash)0xE7CF3C4F9F489F0CUL, handle);
                if (hasTrailer)
                {
                    if (!_nitroTrailerWarningShown)
                        Notify("Nitro is disabled while towing a trailer for stability.");
                    _nitroTrailerWarningShown = true;
                }
                else
                {
                    _nitroTrailerWarningShown = false;
                    float currentSpeed = Function.Call<float>(Hash.GET_ENTITY_SPEED, handle);
                    Function.Call((Hash)0xAB54A438726D25D5UL, handle, Math.Min(95.0f, currentSpeed + 0.85f));
                }
            }
            else
            {
                _nitroTrailerWarningShown = false;
            }
            if (_settings.HornJump && Function.Call<bool>((Hash)0x580417101DDB492FUL, 0, 86))
                Function.Call((Hash)0xC5F68BE9613E2D18UL, handle, 1, 0.0f, 0.0f, 8.5f, 0.0f, 0.0f, 0.0f, 0, false, true, true, false, true);
        }

        private void DrawSpeedometer(Ped ped)
        {
            if (ped == null || !ped.IsInVehicle()) return;
            float speed = Function.Call<float>(Hash.GET_ENTITY_SPEED, ped.CurrentVehicle.Handle);
            string unit = _settings.SpeedUnitMph ? "MPH" : "KM/H";
            speed *= _settings.SpeedUnitMph ? 2.236936f : 3.6f;
            DrawText(((int)speed).ToString() + " " + unit, 0.875f, 0.91f, 0.42f, 255, 255, 255, 235);
        }

        private void SetWantedLevel(int level)
        {
            Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, Game.Player, level, false);
            Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, Game.Player, false);
            Notify("Wanted level set to " + level + ".");
        }

        private void CleanPlayer()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            Function.Call(Hash.CLEAR_PED_BLOOD_DAMAGE, ped.Handle);
            Function.Call((Hash)0x9C720776DAA43E7EUL, ped.Handle);
            Function.Call((Hash)0x6585D955A68452A5UL, ped.Handle);
            Notify("Clothes and character cleaned.");
        }

        private void SuicidePlayer()
        {
            Ped ped = Game.Player.Character;
            if (ped != null && ped.Handle != 0)
                Function.Call(Hash.SET_ENTITY_HEALTH, ped.Handle, 0);
        }

        private void RemoveAllWeapons()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            Function.Call((Hash)0xF25DF915FA38C5F3UL, ped.Handle, true);
            // AutoGiveWeapons is a one-time startup action; do not immediately re-grant
            // the arsenal on the next Tick after the user explicitly removes it.
            _autoLoadoutGranted = true;
            Notify("All weapons removed.");
        }

        private bool TryGetCurrentVehicle(out Vehicle vehicle)
        {
            Ped ped = Game.Player.Character;
            vehicle = ped != null && ped.IsInVehicle() ? ped.CurrentVehicle : null;
            if (vehicle == null || vehicle.Handle == 0)
            {
                Notify("Enter a vehicle first.");
                return false;
            }
            return true;
        }

        private void MaxTuneVehicle()
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            if (!vehicle.Exists())
            {
                Notify("Current vehicle is no longer available.");
                return;
            }

            int handle = vehicle.Handle;
            int supportedSlots = 0;
            int appliedSlots = 0;
            int verifiedSlots = 0;
            int failedSlots = 0;
            int toggleAttempts = 0;
            int verifiedToggles = 0;
            bool tintApplied = false;
            bool neonApplied = false;
            bool wheelsApplied = false;
            try
            {
                Function.Call((Hash)0x1F2AA07F00B3217AUL, handle, 0); // SET_VEHICLE_MOD_KIT

                // Prefer High End rims, then try other wheel families if the model
                // has no parts in that family. The highest available wheel index is used.
                int[] wheelTypes = new int[] { 7, 5, 0, 4, 1, 3, 2 };
                for (int wheelTypeIndex = 0; wheelTypeIndex < wheelTypes.Length; wheelTypeIndex++)
                {
                    try
                    {
                        Function.Call((Hash)0x487EB21CC7295BA1UL, handle, wheelTypes[wheelTypeIndex]); // SET_VEHICLE_WHEEL_TYPE
                        int wheelCount = Function.Call<int>((Hash)0xE38E9162A2500646UL, handle, 23);
                        if (wheelCount > 0)
                        {
                            Function.Call((Hash)0x6AF0636DDEDCB6DDUL, handle, 23, wheelCount - 1, false);
                            int currentWheel = Function.Call<int>((Hash)0x772960298DA26FDBUL, handle, 23);
                            wheelsApplied = currentWheel == wheelCount - 1;
                            supportedSlots++;
                            appliedSlots++;
                            if (wheelsApplied) verifiedSlots++; else failedSlots++;
                            break;
                        }
                    }
                    catch (Exception wheelException)
                    {
                        LogException("MaxTuneVehicle wheel type " + wheelTypes[wheelTypeIndex], wheelException);
                    }
                }

                // Standard appearance and performance slots. Wheels are handled above
                // because their available options depend on the selected wheel family.
                bool isNebula = Function.Call<uint>(Hash.GET_ENTITY_MODEL, handle) == GetHash("nebula");
                for (int modType = 0; modType <= 49; modType++)
                {
                    if (modType == 18 || modType == 20 || modType == 22 || modType == 23 || modType == 24 ||
                        (isNebula && modType == 7)) continue;
                    try
                    {
                        int count = Function.Call<int>((Hash)0xE38E9162A2500646UL, handle, modType);
                        if (count <= 0) continue;
                        supportedSlots++;
                        int bestIndex = count - 1;
                        Function.Call((Hash)0x6AF0636DDEDCB6DDUL, handle, modType, bestIndex, false);
                        appliedSlots++;
                        int currentIndex = Function.Call<int>((Hash)0x772960298DA26FDBUL, handle, modType);
                        if (currentIndex == bestIndex) verifiedSlots++; else failedSlots++;
                    }
                    catch (Exception slotException)
                    {
                        failedSlots++;
                        LogException("MaxTuneVehicle slot " + modType, slotException);
                    }
                }

                // Some vehicles expose a separate rear wheel slot.
                try
                {
                    int rearWheelCount = Function.Call<int>((Hash)0xE38E9162A2500646UL, handle, 24);
                    if (rearWheelCount > 0)
                    {
                        Function.Call((Hash)0x6AF0636DDEDCB6DDUL, handle, 24, rearWheelCount - 1, false);
                        appliedSlots++;
                        supportedSlots++;
                        if (Function.Call<int>((Hash)0x772960298DA26FDBUL, handle, 24) == rearWheelCount - 1) verifiedSlots++;
                        else failedSlots++;
                    }
                }
                catch (Exception rearWheelException) { LogException("MaxTuneVehicle rear wheels", rearWheelException); }

                int[] toggleModTypes = new int[] { 18, 20, 22 };
                for (int i = 0; i < toggleModTypes.Length; i++)
                {
                    int modType = toggleModTypes[i];
                    try
                    {
                        Function.Call((Hash)0x2A1F4F37F95BAD08UL, handle, modType, true); // TOGGLE_VEHICLE_MOD
                        toggleAttempts++;
                        if (Function.Call<bool>((Hash)0x84B233A8C8FC8AE7UL, handle, modType)) verifiedToggles++;
                        else failedSlots++;
                    }
                    catch (Exception toggleException)
                    {
                        failedSlots++;
                        LogException("MaxTuneVehicle toggle " + modType, toggleException);
                    }
                }

                // Apply the darkest factory tint (Limo = 5) where the model supports glass.
                try
                {
                    Function.Call((Hash)0x57C51E6BAD752696UL, handle, 5); // SET_VEHICLE_WINDOW_TINT
                    tintApplied = Function.Call<int>((Hash)0x0EE21293DAD47C95UL, handle) == 5; // GET_VEHICLE_WINDOW_TINT
                }
                catch (Exception tintException) { LogException("MaxTuneVehicle limo tint", tintException); }

                try
                {
                    for (int side = 0; side < 4; side++)
                        Function.Call((Hash)0x2AA720E4287BF269UL, handle, side, true);
                    Function.Call((Hash)0x8E0A582209A62695UL, handle, 255, 0, 0);
                    neonApplied = true;
                }
                catch (Exception neonException) { LogException("MaxTuneVehicle neon", neonException); }

                // Make tires bulletproof independently from the optional vehicle god mode.
                Function.Call(Hash.SET_VEHICLE_TYRES_CAN_BURST, handle, false);
                Function.Call(Hash.SET_VEHICLE_WHEELS_CAN_BREAK, handle, false);
                _settings.BulletproofTires = true;
                SaveSettings();

                // Texture liveries use a separate native from mod-kit liveries (slot 48).
                try
                {
                    int liveryCount = Function.Call<int>((Hash)0x87B63E25A529D526UL, handle);
                    if (liveryCount > 0)
                    {
                        Function.Call((Hash)0x60BF608F1B8CD1B6UL, handle, liveryCount - 1);
                        appliedSlots++;
                        supportedSlots++;
                    }
                }
                catch (Exception liveryException) { LogException("MaxTuneVehicle texture livery", liveryException); }

                int totalVerified = verifiedSlots + verifiedToggles;
                int totalAttempts = appliedSlots + toggleAttempts;
                Log("Max tuning result: model=" + vehicle.Model.Hash + ", supported slots=" + supportedSlots +
                    ", attempts=" + totalAttempts + ", verified=" + totalVerified + ", failed/unsupported=" + failedSlots +
                    ", high-end wheels=" + wheelsApplied + ", limo tint=" + tintApplied +
                    ", red neon=" + neonApplied + ", bulletproof tires=true.");

                Notify("Max Tuning applied: " + totalVerified + "/" + totalAttempts + " parts verified; high-end wheels " +
                    (wheelsApplied ? "yes" : "not available") + ", limo tint " + (tintApplied ? "yes" : "unsupported") +
                    ", red neon " + (neonApplied ? "ON" : "unsupported") + ", bulletproof tires ON.");
            }
            catch (Exception ex)
            {
                LogException("MaxTuneVehicle", ex);
                NotifyError("Max Tuning");
            }
        }

        private void DeleteCurrentVehicle()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0 || !ped.IsInVehicle())
            {
                Notify("Enter the vehicle you want to delete first.");
                return;
            }

            Vehicle vehicle = ped.CurrentVehicle;
            if (vehicle == null || vehicle.Handle == 0 || !vehicle.Exists())
            {
                Notify("Current vehicle is not available.");
                return;
            }

            _pendingVehicleDeleteHandle = vehicle.Handle;
            Function.Call((Hash)0xD3DBCE61A490BE02UL, ped.Handle, vehicle.Handle, 0);
            Notify("Leaving vehicle. It will be deleted safely after you exit.");
        }

        private void ProcessPendingVehicleDeletion(Ped ped)
        {
            if (_pendingVehicleDeleteHandle == 0 || ped == null || ped.Handle == 0) return;
            if (ped.IsInVehicle() && ped.CurrentVehicle != null && ped.CurrentVehicle.Handle == _pendingVehicleDeleteHandle)
                return;

            int handle = _pendingVehicleDeleteHandle;
            _pendingVehicleDeleteHandle = 0;
            try
            {
                Vehicle vehicle = new Vehicle(handle);
                if (vehicle.Exists()) vehicle.Delete();
                Notify("Vehicle deleted safely.");
            }
            catch (Exception ex)
            {
                LogException("DeleteCurrentVehicle", ex);
                Notify("Vehicle could not be deleted. See log.");
            }
        }

        private void ToggleSpeedUnit()
        {
            _settings.SpeedUnitMph = !_settings.SpeedUnitMph;
            SaveSettings();
            Notify("Speedometer unit: " + (_settings.SpeedUnitMph ? "MPH" : "KM/H"));
        }

        private void FlipVehicle()
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, vehicle.Handle);
            Notify("Vehicle placed upright.");
        }

        private void SetAllVehicleDoors(bool open)
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            int doorCount = Function.Call<int>((Hash)0x92922A607497B14DUL, vehicle.Handle);
            if (doorCount <= 0)
            {
                Notify("This vehicle has no standard doors to operate.");
                return;
            }
            if (doorCount > 6) doorCount = 6;

            for (int door = 0; door < doorCount; door++)
            {
                if (open) Function.Call((Hash)0x7C65DAC73C35C862UL, vehicle.Handle, door, false, false);
                else Function.Call((Hash)0x93D9BD300D7789E5UL, vehicle.Handle, door, false);
            }
            Notify(open ? "All available doors opened." : "All available doors closed.");
        }

        private void SetVehicleNeons(bool enabled)
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            for (int side = 0; side < 4; side++)
                Function.Call((Hash)0x2AA720E4287BF269UL, vehicle.Handle, side, enabled);
            if (enabled)
                Function.Call((Hash)0x8E0A582209A62695UL, vehicle.Handle, 255, 0, 0);
            Notify(enabled ? "Neon underglow enabled (red)." : "Neon underglow disabled.");
        }

        private void SetVehicleTint()
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            Function.Call((Hash)0x57C51E6BAD752696UL, vehicle.Handle, 1);
            Notify("Limo window tint applied.");
        }

        private void SetVehicleColours(int primary, int secondary)
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            Function.Call((Hash)0x4F1D4BE3A7F24601UL, vehicle.Handle, primary, secondary);
            Notify("Vehicle paint changed.");
        }

        private void SetVehiclePlate(string text)
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            Function.Call((Hash)0x95A88F0B409CDA47UL, vehicle.Handle, text);
            Notify("License plate updated.");
        }

        private void StartAutopilot()
        {
            Vehicle vehicle;
            if (!TryGetCurrentVehicle(out vehicle)) return;
            if (!Function.Call<bool>((Hash)0x1DD1F58F493F1DA5UL))
            {
                Notify("Place a waypoint on the map first.");
                return;
            }
            int blip = Function.Call<int>((Hash)0x1BEDE233E6CD2A1FUL, 8);
            Vector3 destination = Function.Call<Vector3>((Hash)0xFA7C7F0AADF25D09UL, blip);
            Ped ped = Game.Player.Character;
            Function.Call((Hash)0x158BB33F920D360CUL, ped.Handle, vehicle.Handle, destination.X, destination.Y, destination.Z, 35.0f, 786603, 10.0f);
            Notify("Waypoint autopilot started. Use Stop Autopilot to cancel.");
        }

        private void StopAutopilot()
        {
            Ped ped = Game.Player.Character;
            if (ped != null && ped.Handle != 0) Function.Call(Hash.CLEAR_PED_TASKS, ped.Handle);
            Notify("Autopilot stopped.");
        }

        private void CaptureSkinState(Ped ped)
        {
            if (_skinSnapshotCaptured || ped == null || ped.Handle == 0) return;
            _skinRestorePosition = ped.Position;
            _skinRestoreHeading = ped.Heading;
            _skinRestoreHealth = ped.Health;
            _skinRestoreArmour = Function.Call<int>(Hash.GET_PED_ARMOUR, ped.Handle);
            _skinSelectedWeapon = Function.Call<uint>(Hash.GET_SELECTED_PED_WEAPON, ped.Handle);
            _skinWeaponSnapshot.Clear();

            for (int i = 0; i < _weaponNames.Length; i++)
            {
                uint weaponHash = GetHash(_weaponNames[i]);
                if (weaponHash == 0 || !Function.Call<bool>(Hash.IS_WEAPON_VALID, weaponHash)) continue;
                if (!Function.Call<bool>((Hash)0x8DECB02F88F428BCUL, ped.Handle, weaponHash, false)) continue;
                int ammo = Function.Call<int>((Hash)0x015A522136D7F951UL, ped.Handle, weaponHash);
                _skinWeaponSnapshot.Add(new WeaponSnapshot(weaponHash, Math.Max(0, ammo)));
            }
            _skinSnapshotCaptured = true;
            Log("Captured skin-change state. Preserved weapons: " + _skinWeaponSnapshot.Count);
        }

        private void QueueSkinStateRestore()
        {
            _pendingSkinStateRestore = true;
            _skinRestoreFrames = 12;
        }

        private void ProcessPendingSkinStateRestore()
        {
            if (!_pendingSkinStateRestore) return;
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;

            try
            {
                // Re-apply the original location and equipment while the game replaces the
                // player ped. If a protagonist model request starts the cinematic character
                // switch, stop that sequence and keep the replacement ped at the current spot.
                if (Function.Call<bool>((Hash)0xD9D2CFFF49FAB35FUL))
                    Function.Call((Hash)0x95C0A5BBDC189AA1UL); // STOP_PLAYER_SWITCH
                Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, ped.Handle,
                    _skinRestorePosition.X, _skinRestorePosition.Y, _skinRestorePosition.Z, false, false, false);
                Function.Call(Hash.SET_ENTITY_HEADING, ped.Handle, _skinRestoreHeading);

                if (_skinRestoreFrames == 12 && _skinSnapshotCaptured)
                {
                    int maxHealth = Function.Call<int>(Hash.GET_ENTITY_MAX_HEALTH, ped.Handle);
                    int health = Math.Max(1, Math.Min(_skinRestoreHealth, maxHealth > 0 ? maxHealth : 200));
                    Function.Call(Hash.SET_ENTITY_HEALTH, ped.Handle, health);
                    Function.Call(Hash.SET_PED_ARMOUR, ped.Handle, _skinRestoreArmour);
                    RestoreSkinWeapons(ped);
                    if (_clearSkinSnapshotAfterRestore)
                    {
                        _skinSnapshotCaptured = false;
                        _skinWeaponSnapshot.Clear();
                        _clearSkinSnapshotAfterRestore = false;
                    }
                }
            }
            catch (Exception ex)
            {
                LogException("Skin state restore", ex);
            }
            finally
            {
                _skinRestoreFrames--;
                if (_skinRestoreFrames <= 0) _pendingSkinStateRestore = false;
            }
        }

        private void RestoreSkinWeapons(Ped ped)
        {
            for (int i = 0; i < _skinWeaponSnapshot.Count; i++)
            {
                WeaponSnapshot item = _skinWeaponSnapshot[i];
                if (item == null) continue;
                try
                {
                    if (!Function.Call<bool>(Hash.IS_WEAPON_VALID, item.Hash)) continue;
                    Function.Call(Hash.GIVE_WEAPON_TO_PED, ped.Handle, item.Hash, item.Ammo, false, false);
                    ApplyPremiumToWeapon(ped, item.Hash);
                }
                catch (Exception ex) { LogException("Restore skin weapon " + item.Hash, ex); }
            }
            try
            {
                if (_skinSelectedWeapon != 0 && Function.Call<bool>(Hash.IS_WEAPON_VALID, _skinSelectedWeapon))
                    Function.Call(Hash.SET_CURRENT_PED_WEAPON, ped.Handle, _skinSelectedWeapon, true);
            }
            catch (Exception ex) { LogException("Restore selected skin weapon", ex); }
        }

        private void ChangePlayerModel(string modelName)
        {
            try
            {
                Ped currentPed = Game.Player.Character;
                if (currentPed == null || currentPed.Handle == 0) return;
                Model model = new Model(modelName);
                if (!model.IsValid || !model.IsInCdImage || !model.Request(5000))
                {
                    Notify("Ped model unavailable: " + modelName);
                    model.MarkAsNoLongerNeeded();
                    return;
                }

                CaptureSkinState(currentPed);
                Function.Call((Hash)0x00A1CADD00108836UL, Game.Player, (uint)model.Hash);
                model.MarkAsNoLongerNeeded();
                QueueSkinStateRestore();
                Notify("Player skin changed. Original weapons and position are being preserved.");
            }
            catch (Exception ex)
            {
                LogException("ChangePlayerModel " + modelName, ex);
                Notify("Could not change player model. See log.");
            }
        }

        private void RestoreOriginalModel()
        {
            if (!_originalModelCaptured || _originalModelHash == 0)
            {
                Notify("Original player model has not been captured yet.");
                return;
            }
            try
            {
                Function.Call((Hash)0x00A1CADD00108836UL, Game.Player, _originalModelHash);
                QueueSkinStateRestore();
                _pendingSkinStateRestore = true;
                _skinRestoreFrames = 12;
                Notify("Original model restored. Weapons, health, and position are being restored.");
                _clearSkinSnapshotAfterRestore = true;
            }
            catch (Exception ex)
            {
                LogException("RestoreOriginalModel", ex);
                Notify("Could not restore original model. See log.");
            }
        }

        private void SpawnBodyguard(string modelName)
        {
            try
            {
                Model model = new Model(modelName);
                if (!model.IsValid || !model.IsInCdImage || !model.Request(5000))
                {
                    Notify("Bodyguard model unavailable: " + modelName);
                    model.MarkAsNoLongerNeeded();
                    return;
                }
                Ped player = Game.Player.Character;
                if (player == null || player.Handle == 0)
                {
                    model.MarkAsNoLongerNeeded();
                    Notify("Player character is not available right now.");
                    return;
                }
                Vector3 forward = Function.Call<Vector3>(Hash.GET_ENTITY_FORWARD_VECTOR, player.Handle);
                Vector3 position = player.Position + forward * (2.0f + _bodyguards.Count);
                int guard = Function.Call<int>((Hash)0xD49F9B0955C367DEUL, 4, (uint)model.Hash, position.X, position.Y, position.Z, player.Heading, true, false);
                model.MarkAsNoLongerNeeded();
                if (guard == 0) { Notify("Could not create bodyguard."); return; }
                EnsureBodyguardGroup(player);
                EnsureBodyguardRelationshipGroup(player);
                if (_bodyguardRelationshipGroupHash != 0)
                    Function.Call((Hash)0xC80A74AC829DDD92UL, guard, _bodyguardRelationshipGroupHash); // SET_PED_RELATIONSHIP_GROUP_HASH
                Function.Call((Hash)0x9F3480FE65DB31B5UL, guard, _bodyguardGroupId); // SET_PED_AS_GROUP_MEMBER
                Function.Call((Hash)0x3DBFC55D5C9BB447UL, guard, true); // SET_PED_NEVER_LEAVES_GROUP
                Function.Call((Hash)0x2E2F4240B3F24647UL, guard, true); // SET_PED_CAN_TELEPORT_TO_GROUP_LEADER
                Function.Call((Hash)0xC7622C0D36B2FDA8UL, guard, 2);
                Function.Call((Hash)0x9F7794730795E019UL, guard, 46, true);
                Function.Call((Hash)0x304AE42E357B8C7EUL, guard, player.Handle,
                    -1.0f, -1.0f, 0.0f, 3.0f, -1, 3.0f, true); // TASK_FOLLOW_TO_OFFSET_OF_ENTITY
                Function.Call((Hash)0x971D38760FBC02EFUL, guard, true); // SET_PED_KEEP_TASK
                Function.Call(Hash.SET_PED_ACCURACY, guard, 70);
                Function.Call(Hash.SET_PED_ARMOUR, guard, 100);
                uint weapon = Function.Call<uint>(Hash.GET_HASH_KEY, "WEAPON_CARBINERIFLE");
                Function.Call(Hash.GIVE_WEAPON_TO_PED, guard, weapon, 9999, false, true);
                _bodyguards.Add(guard);
                Notify("Bodyguard spawned. Total: " + _bodyguards.Count);
            }
            catch (Exception ex)
            {
                LogException("SpawnBodyguard", ex);
                Notify("Bodyguard spawn failed. See log.");
            }
        }

        private void EnsureBodyguardGroup(Ped player)
        {
            if (_bodyguardGroupId < 0)
            {
                _bodyguardGroupId = Function.Call<int>((Hash)0x90370EBE0FEE1A3DUL, 0); // CREATE_GROUP
                if (_bodyguardGroupId >= 0)
                    Function.Call((Hash)0x2A7819605465FBCEUL, player.Handle, _bodyguardGroupId); // SET_PED_AS_GROUP_LEADER
            }
        }

        private void EnsureBodyguardRelationshipGroup(Ped player)
        {
            if (player == null || player.Handle == 0) return;
            try
            {
                if (_bodyguardRelationshipGroupHash == 0)
                {
                    OutputArgument groupOutput = new OutputArgument();
                    try
                    {
                        Function.Call((Hash)0xF372BC22FCB88606UL, "AVERNES_BODYGUARDS", groupOutput);
                        _bodyguardRelationshipGroupHash = groupOutput.GetResult<uint>();
                    }
                    finally { groupOutput.Dispose(); }
                }
                if (_bodyguardRelationshipGroupHash == 0) return;
                uint playerGroup = Function.Call<uint>((Hash)0x7DBDD04862D95F04UL, player.Handle);
                Function.Call((Hash)0xBF25EB89375A37ADUL, 0, _bodyguardRelationshipGroupHash, playerGroup);
                Function.Call((Hash)0xBF25EB89375A37ADUL, 0, playerGroup, _bodyguardRelationshipGroupHash);
            }
            catch (Exception ex) { LogException("EnsureBodyguardRelationshipGroup", ex); }
        }

        private void ProcessBodyguardFollowing(Ped player)
        {
            if (_bodyguards.Count == 0 || player == null || player.Handle == 0) return;
            int now = Environment.TickCount;
            if (unchecked(now - _lastBodyguardFollowTick) < 1500) return;
            _lastBodyguardFollowTick = now;

            for (int i = _bodyguards.Count - 1; i >= 0; i--)
            {
                int handle = _bodyguards[i];
                try
                {
                    if (!Function.Call<bool>(Hash.DOES_ENTITY_EXIST, handle))
                    {
                        _bodyguards.RemoveAt(i);
                        continue;
                    }

                    bool inCombat = Function.Call<bool>((Hash)0x4859F1FC66A6278EUL, handle, 0);
                    if (inCombat) continue;

                    Vector3 guardPosition = Function.Call<Vector3>(Hash.GET_ENTITY_COORDS, handle, true);
                    float distance = Function.Call<float>(Hash.GET_DISTANCE_BETWEEN_COORDS,
                        guardPosition.X, guardPosition.Y, guardPosition.Z,
                        player.Position.X, player.Position.Y, player.Position.Z, true);
                    if (distance > 5.0f)
                    {
                        Function.Call((Hash)0x304AE42E357B8C7EUL, handle, player.Handle,
                            -1.0f, -1.0f, 0.0f, 3.0f, -1, 3.0f, true);
                    }
                }
                catch (Exception ex) { LogException("Bodyguard follow", ex); }
            }
        }

        private void DismissAllBodyguards()
        {
            int dismissed = 0;
            for (int i = _bodyguards.Count - 1; i >= 0; i--)
            {
                int handle = _bodyguards[i];
                try
                {
                    if (Function.Call<bool>(Hash.DOES_ENTITY_EXIST, handle))
                    {
                        Function.Call(Hash.CLEAR_PED_TASKS, handle);
                        Function.Call((Hash)0x971D38760FBC02EFUL, handle, false); // SET_PED_KEEP_TASK
                        Function.Call((Hash)0xED74007FFB146BC2UL, handle); // REMOVE_PED_FROM_GROUP
                        Function.Call((Hash)0xAD738C3085FE7E11UL, handle, true, true); // SET_ENTITY_AS_MISSION_ENTITY
                        Ped guard = new Ped(handle);
                        if (guard.Exists()) guard.Delete();
                        dismissed++;
                    }
                }
                catch (Exception ex) { LogException("DismissBodyguard", ex); }
            }
            _bodyguards.Clear();
            if (_bodyguardGroupId >= 0)
            {
                try { Function.Call((Hash)0x8EB2F69076AF7053UL, _bodyguardGroupId); } // REMOVE_GROUP
                catch (Exception ex) { LogException("RemoveBodyguardGroup", ex); }
                _bodyguardGroupId = -1;
            }
            if (_bodyguardRelationshipGroupHash != 0)
            {
                try { Function.Call((Hash)0xB6BA2444AB393DA2UL, _bodyguardRelationshipGroupHash); } // REMOVE_RELATIONSHIP_GROUP
                catch (Exception ex) { LogException("RemoveBodyguardRelationshipGroup", ex); }
                _bodyguardRelationshipGroupHash = 0;
            }
            if (dismissed > 0) Notify("Dismissed " + dismissed + " bodyguards.");
            else Notify("No active bodyguards.");
        }

        private void StartPlayerScenario(string scenario)
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            Function.Call((Hash)0xAAA34F8A7CB32098UL, ped.Handle); // CLEAR_PED_TASKS_IMMEDIATELY
            Function.Call((Hash)0x142A02425FF02BD9UL, ped.Handle, scenario, 0, true);
        }

        private void StopPlayerAnimation()
        {
            Ped ped = Game.Player.Character;
            if (ped != null && ped.Handle != 0)
                Function.Call((Hash)0xAAA34F8A7CB32098UL, ped.Handle); // CLEAR_PED_TASKS_IMMEDIATELY
        }

        private void TeleportToWaypoint()
        {
            if (!Function.Call<bool>((Hash)0x1DD1F58F493F1DA5UL))
            {
                Notify("No waypoint selected on the map.");
                return;
            }
            if (_waypointTeleportPending)
            {
                Notify("Waypoint teleport is already loading.");
                return;
            }
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            int entityHandle = ped.Handle;
            if (ped.IsInVehicle() && ped.CurrentVehicle != null && ped.CurrentVehicle.Handle != 0)
                entityHandle = ped.CurrentVehicle.Handle;
            int blip = Function.Call<int>((Hash)0x1BEDE233E6CD2A1FUL, 8);
            Vector3 destination = Function.Call<Vector3>((Hash)0xFA7C7F0AADF25D09UL, blip);
            _waypointTeleportX = destination.X;
            _waypointTeleportY = destination.Y;
            _waypointTeleportEntityHandle = entityHandle;
            _waypointTeleportOriginalPosition = Function.Call<Vector3>(Hash.GET_ENTITY_COORDS, entityHandle, true);
            _waypointTeleportDeadlineUtc = DateTime.UtcNow.AddSeconds(15);
            _waypointTeleportPending = true;
            _waypointTeleportPrepared = false;
            Notify("Loading waypoint ground and collision...");
        }

        private void ProcessPendingWaypointTeleport(Ped ped)
        {
            if (!_waypointTeleportPending || ped == null || ped.Handle == 0) return;
            int handle = _waypointTeleportEntityHandle;
            try
            {
                if (!Function.Call<bool>((Hash)0x7239B21A38F536BAUL, handle))
                {
                    _waypointTeleportPending = false;
                    Notify("Waypoint teleport cancelled: target entity unavailable.");
                    return;
                }
                if (!_waypointTeleportPrepared)
                {
                    Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, handle,
                        _waypointTeleportX, _waypointTeleportY, 1000.0f, false, false, false);
                    Function.Call((Hash)0x428CA6DBD1094446UL, handle, true); // FREEZE_ENTITY_POSITION
                    _waypointTeleportPrepared = true;
                }
                Function.Call((Hash)0x07503F7948F491A7UL, _waypointTeleportX, _waypointTeleportY, 1000.0f);
                OutputArgument groundOutput = new OutputArgument();
                bool foundGround;
                float groundZ = 0.0f;
                try
                {
                    foundGround = Function.Call<bool>((Hash)0xC906A7DAB05C8D2BUL,
                        _waypointTeleportX, _waypointTeleportY, 1000.0f, groundOutput, false, false);
                    if (foundGround) groundZ = groundOutput.GetResult<float>();
                }
                finally { groundOutput.Dispose(); }

                if (foundGround && !Single.IsNaN(groundZ) && !Single.IsInfinity(groundZ) &&
                    groundZ >= -1000.0f && groundZ <= 5000.0f)
                {
                    Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, handle,
                        _waypointTeleportX, _waypointTeleportY, groundZ + 1.5f, false, false, false);
                    Function.Call((Hash)0x428CA6DBD1094446UL, handle, false);
                    Function.Call((Hash)0x1C99BB7B6E96D16FUL, handle, 0.0f, 0.0f, 0.0f);
                    _waypointTeleportPending = false;
                    _waypointTeleportPrepared = false;
                    Notify("Teleported to waypoint on loaded ground.");
                    return;
                }
                if (DateTime.UtcNow >= _waypointTeleportDeadlineUtc)
                {
                    Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, handle,
                        _waypointTeleportOriginalPosition.X, _waypointTeleportOriginalPosition.Y,
                        _waypointTeleportOriginalPosition.Z, false, false, false);
                    Function.Call((Hash)0x428CA6DBD1094446UL, handle, false);
                    _waypointTeleportPending = false;
                    _waypointTeleportPrepared = false;
                    Notify("Waypoint teleport cancelled: ground did not load; original position restored.");
                    LogFailure("Waypoint teleport", "Ground/collision loading timed out.");
                }
            }
            catch (Exception ex)
            {
                try
                {
                    if (_waypointTeleportPrepared &&
                        Function.Call<bool>((Hash)0x7239B21A38F536BAUL, handle))
                    {
                        Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, handle,
                            _waypointTeleportOriginalPosition.X, _waypointTeleportOriginalPosition.Y,
                            _waypointTeleportOriginalPosition.Z, false, false, false);
                        Function.Call((Hash)0x428CA6DBD1094446UL, handle, false);
                    }
                }
                catch (Exception restoreEx) { LogException("Waypoint teleport rollback", restoreEx); }
                _waypointTeleportPending = false;
                _waypointTeleportPrepared = false;
                LogException("ProcessPendingWaypointTeleport", ex);
                Notify("Waypoint teleport failed safely. See errors.log.");
            }
        }

        private void TeleportTo(float x, float y, float z)
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            int handle = ped.Handle;
            if (ped.IsInVehicle() && ped.CurrentVehicle != null && ped.CurrentVehicle.Handle != 0)
                handle = ped.CurrentVehicle.Handle;
            Function.Call(Hash.SET_ENTITY_COORDS_NO_OFFSET, handle, x, y, z, false, false, false);
            Function.Call((Hash)0x1C99BB7B6E96D16FUL, handle, 0.0f, 0.0f, 0.0f);
            Notify("Teleported.");
        }

        private void SetWeather(string weather)
        {
            _settings.Weather = NormalizeWeather(weather);
            _settings.LockWeather = true;
            Function.Call(Hash.SET_WEATHER_TYPE_NOW_PERSIST, _settings.Weather);
            SaveSettings();
            Notify("Weather: " + _settings.Weather);
        }

        private void SetClockTime(int hour, int minute)
        {
            Function.Call((Hash)0x47C3B5848C3E45D8UL, hour, minute, 0);
            Notify("Game time changed.");
        }

        private void ClearNearbyArea()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            Vector3 position = ped.Position;
            if (ped.IsInVehicle())
            {
                Notify("Exit your vehicle before clearing nearby traffic and pedestrians.");
                return;
            }

            // CLEAR_AREA_OF_VEHICLES requires all 11 parameters; the previous call
            // omitted trailing arguments and used an incorrect peds native hash.
            Function.Call((Hash)0x01C7B9B38428AEB6UL, position.X, position.Y, position.Z,
                35.0f, false, false, false, false, false, false, 0);
            Function.Call((Hash)0xBE31FD6CE464AC59UL, position.X, position.Y, position.Z, 25.0f, 0);
            Notify("Nearby traffic and pedestrians cleared.");
        }

        private void HealPlayer()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            int maxHealth = Function.Call<int>(Hash.GET_ENTITY_MAX_HEALTH, ped.Handle);
            Function.Call(Hash.SET_ENTITY_HEALTH, ped.Handle, maxHealth > 0 ? maxHealth : 200);
            Function.Call(Hash.SET_PED_ARMOUR, ped.Handle, 100);
            Function.Call(Hash.CLEAR_PED_BLOOD_DAMAGE, ped.Handle);
            Notify("Health and armour restored.");
        }

        private void ClearWantedLevel()
        {
            Function.Call(Hash.SET_PLAYER_WANTED_LEVEL, Game.Player, 0, false);
            Function.Call(Hash.SET_PLAYER_WANTED_LEVEL_NOW, Game.Player, false);
            Notify("Wanted level cleared.");
        }

        private void TeleportForward()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            Vector3 target = Function.Call<Vector3>(Hash.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS, ped.Handle, 0.0f, 3.0f, 0.0f);
            TeleportTo(target.X, target.Y, target.Z);
            Notify("Teleported 3 metres forward.");
        }

        private void RepairCurrentVehicle()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || !ped.IsInVehicle())
            {
                Notify("Enter a vehicle first.");
                return;
            }
            Vehicle vehicle = ped.CurrentVehicle;
            if (vehicle == null || vehicle.Handle == 0) return;
            Function.Call(Hash.SET_VEHICLE_FIXED, vehicle.Handle);
            Function.Call(Hash.SET_VEHICLE_DEFORMATION_FIXED, vehicle.Handle);
            Function.Call(Hash.SET_VEHICLE_DIRT_LEVEL, vehicle.Handle, 0.0f);
            Notify("Vehicle repaired.");
        }

        private void AddStoryModeMoney(int amount)
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            uint modelHash = Function.Call<uint>(Hash.GET_ENTITY_MODEL, ped.Handle);
            bool protagonist = modelHash == GetHash("player_zero") ||
                modelHash == GetHash("player_one") || modelHash == GetHash("player_two");
            if (!protagonist)
            {
                Notify("Cash can only be added as Michael, Franklin, or Trevor. Restore a protagonist skin first.");
                return;
            }

            try
            {
                int currentCash = Game.Player.Money;
                long total = (long)currentCash + amount;
                if (total > StoryCashLimit) total = StoryCashLimit;
                Game.Player.Money = (int)total;
                _hideCashChangeUntilUtc = DateTime.UtcNow.AddSeconds(8);
                Notify("Added $" + amount.ToString("N0") + ". New cash: $" + ((int)total).ToString("N0"));
                Log("Story Mode cash changed: " + currentCash + " -> " + (int)total);
            }
            catch (Exception ex)
            {
                LogException("AddStoryModeMoney", ex);
                Notify("Cash update failed. See log.");
            }
        }

        private void SetStoryModeMoney(int amount)
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            uint modelHash = Function.Call<uint>(Hash.GET_ENTITY_MODEL, ped.Handle);
            bool protagonist = modelHash == GetHash("player_zero") ||
                modelHash == GetHash("player_one") || modelHash == GetHash("player_two");
            if (!protagonist)
            {
                Notify("Cash can only be set as Michael, Franklin, or Trevor. Restore a protagonist skin first.");
                return;
            }

            try
            {
                int targetCash = Math.Max(0, Math.Min(StoryCashLimit, amount));
                int previousCash = Game.Player.Money;
                Game.Player.Money = targetCash;
                _hideCashChangeUntilUtc = DateTime.UtcNow.AddSeconds(8);
                Notify("Cash set to $" + targetCash.ToString("N0"));
                Log("Story Mode cash set: " + previousCash + " -> " + targetCash);
            }
            catch (Exception ex)
            {
                LogException("SetStoryModeMoney", ex);
                Notify("Cash update failed. See log.");
            }
        }

        private void GiveFullWeaponLoadoutToPlayer()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            GiveFullWeaponLoadout(ped);
            _autoLoadoutGranted = true;
            Notify("Weapon arsenal delivered.");
        }

        private void GiveFullWeaponLoadout(Ped ped)
        {
            int granted = 0;
            for (int i = 0; i < _weaponNames.Length; i++)
            {
                uint weaponHash = GetHash(_weaponNames[i]);
                if (weaponHash == 0 || !Function.Call<bool>(Hash.IS_WEAPON_VALID, weaponHash)) continue;

                Function.Call(Hash.GIVE_WEAPON_TO_PED, ped.Handle, weaponHash, AmmoPerWeapon, false, false);
                ApplyPremiumToWeapon(ped, weaponHash);
                granted++;
            }

            uint preferredWeapon = GetHash("WEAPON_CARBINERIFLE");
            if (preferredWeapon != 0 && Function.Call<bool>(Hash.IS_WEAPON_VALID, preferredWeapon))
                Function.Call(Hash.SET_CURRENT_PED_WEAPON, ped.Handle, preferredWeapon, true);

            Log("Weapon loadout applied. Valid weapons granted: " + granted);
        }

        private void ApplyWeaponFinishToCurrentLoadout()
        {
            Ped ped = Game.Player.Character;
            if (ped == null || ped.Handle == 0) return;
            int owned = 0;
            int finished = 0;
            for (int i = 0; i < _weaponNames.Length; i++)
            {
                uint weaponHash = GetHash(_weaponNames[i]);
                if (weaponHash == 0 || !Function.Call<bool>(Hash.IS_WEAPON_VALID, weaponHash)) continue;
                if (!Function.Call<bool>((Hash)0x8DECB02F88F428BCUL, ped.Handle, weaponHash, false)) continue;
                owned++;
                if (ApplyPremiumToWeapon(ped, weaponHash)) finished++;
            }
            if (owned == 0) Notify("No owned weapons found. Give the arsenal first.");
            else if (finished == 0) Notify("No premium tint or finish is available for the owned weapons in this game build.");
            else Notify("Premium finish applied to " + finished + " of " + owned + " owned weapons.");
        }

        private bool ApplyPremiumToWeapon(Ped ped, uint weaponHash)
        {
            bool premiumApplied = false;
            int tintCount = Function.Call<int>((Hash)0x5DCF6C5CAB2E9BF7UL, weaponHash);
            if (tintCount > 1)
            {
                int tintIndex = Math.Min(PremiumWeaponTint, tintCount - 1);
                Function.Call(Hash.SET_PED_WEAPON_TINT_INDEX, ped.Handle, weaponHash, tintIndex);
                premiumApplied = tintIndex > 0;
            }

            for (int i = 0; i < _weaponComponentNames.Length; i++)
            {
                string componentName = _weaponComponentNames[i];
                uint componentHash = GetHash(componentName);
                if (componentHash == 0) continue;
                if (!Function.Call<bool>(Hash.DOES_WEAPON_TAKE_WEAPON_COMPONENT, weaponHash, componentHash)) continue;
                Function.Call(Hash.GIVE_WEAPON_COMPONENT_TO_PED, ped.Handle, weaponHash, componentHash);
                if (componentName.IndexOf("VARMOD_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    componentName.IndexOf("_CAMO_", StringComparison.OrdinalIgnoreCase) >= 0)
                    premiumApplied = true;
            }
            return premiumApplied;
        }

        private uint GetHash(string name)
        {
            return Function.Call<uint>(Hash.GET_HASH_KEY, name);
        }

        private bool LoadVehicleCatalog()
        {
            // Support every layout used by the 1.2.x packages and by manual installs.
            // A malformed first candidate must not prevent trying a valid fallback.
            string[] candidates = new string[]
            {
                _vehicleCatalogPath,
                Path.Combine(_vehiclesDirectory, "vehicles_builtin.json"),
                Path.Combine(_vehiclesDirectory, "vehicle_catalog.json"),
                Path.Combine(_vehiclesDirectory, "vehicle_catalog"),
                _legacyVehicleCatalogPath,
                Path.Combine(_dataDirectory, "vehicles_builtin.json"),
                Path.Combine(_dataDirectory, "Vehicles", "vehicle_catalog.json"),
                Path.Combine(_dataDirectory, "vehicles.json"),
                Path.Combine(_scriptsDirectory, "vehicle_catalog.json"),
                Path.Combine(_scriptsDirectory, "Vehicles", "vehicles.json"),
                Path.Combine(_scriptsDirectory, "Vehicles", "vehicle_catalog.json"),
                Path.Combine(_scriptsDirectory, "YnixTrainer", "vehicle_catalog"),
                Path.Combine(_scriptsDirectory, "YnixTrainer", "vehicles")
            };

            bool foundAny = false;
            Exception lastError = null;
            HashSet<string> checkedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < candidates.Length; i++)
            {
                string candidate = candidates[i];
                if (String.IsNullOrEmpty(candidate) || !checkedPaths.Add(candidate)) continue;
                if (!File.Exists(candidate)) continue;
                foundAny = true;

                try
                {
                    FileInfo info = new FileInfo(candidate);
                    if (info.Length <= 0) throw new InvalidDataException("Vehicle database is empty.");
                    if (info.Length > 2 * 1024 * 1024)
                        throw new InvalidDataException("Vehicle database exceeds the 2 MB safety limit.");

                    string json = File.ReadAllText(candidate);
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    serializer.MaxJsonLength = 2 * 1024 * 1024;
                    serializer.RecursionLimit = 16;
                    List<AddonVehicle> parsed = serializer.Deserialize<List<AddonVehicle>>(json);
                    if (parsed == null) throw new InvalidDataException("Vehicle database root must be a JSON array.");
                    if (parsed.Count > 5000) throw new InvalidDataException("Vehicle database contains more than 5000 entries.");

                    List<AddonVehicle> validated = NormalizeVehicleEntries(parsed);
                    if (validated.Count == 0)
                        throw new InvalidDataException("Vehicle database contains no valid vehicle model names.");

                    // Commit only after a complete candidate is parsed and validated.
                    _vehicleCatalog.Clear();
                    _vehicleCatalog.AddRange(validated);
                    RebuildVehicleSpawnerMenu();
                    Log("Loaded vehicle database: " + _vehicleCatalog.Count + " records from " + candidate);
                    Notify("Vehicle database loaded: " + _vehicleCatalog.Count + " models.");
                    return true;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                    LogException("LoadVehicleCatalog candidate " + candidate, ex);
                }
            }

            if (!foundAny)
            {
                LogFailure("LoadVehicleCatalog", "No candidate vehicle database file exists. Checked: " + String.Join("; ", candidates));
                Notify("Vehicle database not found. Run Build.bat / Install_YnixTrainer.bat or check scripts\\YnixTrainer\\Vehicles.");
            }
            else
            {
                Log("Vehicle database candidates existed, but none passed validation.");
                if (lastError != null) LogException("LoadVehicleCatalog: all candidates failed", lastError);
                Notify("Vehicle database reload failed. Previous valid list was retained; check scripts/YnixTrainer_Logs/errors.log.");
            }
            return false;
        }

        private bool LoadAddonVehicles()
        {
            // Try the user's primary list first, then legacy and packaged fallback copies.
            // An invalid primary file must not block a known-good bundled list.
            string[] candidates = new string[]
            {
                _addonPath,
                Path.Combine(_dataDirectory, "addons"),
                Path.Combine(_dataDirectory, "addons_builtin.json")
            };
            bool foundAny = false;
            Exception lastError = null;
            HashSet<string> checkedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < candidates.Length; i++)
            {
                string addonReadPath = candidates[i];
                if (String.IsNullOrEmpty(addonReadPath) || !checkedPaths.Add(addonReadPath)) continue;
                if (!File.Exists(addonReadPath)) continue;
                foundAny = true;

                try
                {
                    FileInfo info = new FileInfo(addonReadPath);
                    if (info.Length <= 0) throw new InvalidDataException("addons.json is empty.");
                    if (info.Length > 1024 * 1024)
                        throw new InvalidDataException("addons.json exceeds the 1 MB safety limit.");
                    string json = File.ReadAllText(addonReadPath);
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    serializer.MaxJsonLength = 1024 * 1024;
                    serializer.RecursionLimit = 16;
                    List<AddonVehicle> parsed = serializer.Deserialize<List<AddonVehicle>>(json);
                    if (parsed == null) throw new InvalidDataException("addons.json root must be a JSON array.");
                    if (parsed.Count > 2000) throw new InvalidDataException("addons.json contains more than 2000 entries.");

                    List<AddonVehicle> validated = NormalizeVehicleEntries(parsed);
                    if (validated.Count == 0) throw new InvalidDataException("No valid vehicle models were found in addons.json.");

                    // Commit only after the entire candidate parsed and validated.
                    _addonVehicles.Clear();
                    _addonVehicles.AddRange(validated);
                    if (_addonIndex >= _addonVehicles.Count) _addonIndex = 0;
                    Log("Loaded add-on vehicle entries: " + _addonVehicles.Count + " from " + addonReadPath);
                    RebuildVehicleSpawnerMenu();
                    return true;
                }
                catch (Exception ex)
                {
                    lastError = ex;
                    LogException("LoadAddonVehicles candidate " + addonReadPath, ex);
                }
            }

            if (!foundAny)
                Log("No add-on list found. Checked: " + String.Join("; ", candidates));
            else if (lastError != null)
                LogException("LoadAddonVehicles: all candidates failed", lastError);

            Notify("Add-on vehicle list could not be loaded. Previous valid list was retained.");
            RebuildVehicleSpawnerMenu();
            return false;
        }

        private List<AddonVehicle> NormalizeVehicleEntries(List<AddonVehicle> parsed)
        {
            List<AddonVehicle> result = new List<AddonVehicle>();
            HashSet<string> seenModels = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < parsed.Count; i++)
            {
                AddonVehicle item = parsed[i];
                if (item == null || String.IsNullOrWhiteSpace(item.model)) continue;
                string model = item.model.Trim();
                if (!IsSafeVehicleModelName(model))
                {
                    Log("Skipped unsafe/invalid vehicle model value at JSON index " + i + ".");
                    continue;
                }
                model = model.ToLowerInvariant();
                if (!seenModels.Add(model)) continue;

                string name = SanitizeMenuText(String.IsNullOrWhiteSpace(item.name) ? model : item.name, 80, model);
                string category = NormalizeVehicleCategory(String.IsNullOrWhiteSpace(item.category) ? "Other" : item.category);
                string source = SanitizeMenuText(String.IsNullOrWhiteSpace(item.source) ? "custom" : item.source, 48, "custom");
                result.Add(new AddonVehicle { name = name, model = model, id = FormatVehicleModelId(model), category = category, source = source });
            }
            return result;
        }

        private string NormalizeVehicleCategory(string category)
        {
            string value = SanitizeMenuText(category, 48, "Other").Trim().ToLowerInvariant();
            switch (value)
            {
                case "sports classic":
                case "classic": return "Sports Classics";
                case "off road":
                case "offroad":
                case "off-road": return "Off-Road";
                case "helicopter":
                case "helicopters":
                case "planes":
                case "aircraft":
                case "aircraft & helicopters": return "Aircraft & Helicopters";
                case "sedan":
                case "sedans":
                case "coupes":
                case "suvs":
                case "sedans / coupes / suvs": return "Sedans / Coupes / SUVs";
                case "motorcycles":
                case "motorcycles & bicycles": return "Motorcycles & Bicycles";
                case "military":
                case "boats":
                case "boats / military / emergency": return "Boats / Military / Emergency";
                default: return SanitizeMenuText(category, 48, "Other");
            }
        }

        private string SanitizeMenuText(string value, int maxLength, string fallback)
        {
            if (value == null) return fallback;
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            for (int i = 0; i < value.Length && builder.Length < maxLength; i++)
            {
                char c = value[i];
                if (Char.IsControl(c) || c == '~') continue;
                builder.Append(c);
            }
            string cleaned = builder.ToString().Trim();
            return String.IsNullOrWhiteSpace(cleaned) ? fallback : cleaned;
        }

        private bool IsSafeVehicleModelName(string modelName)
        {
            if (String.IsNullOrWhiteSpace(modelName) || modelName.Length > 64) return false;
            for (int i = 0; i < modelName.Length; i++)
            {
                char c = modelName[i];
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') || c == '_')) return false;
            }
            return true;
        }

        private void RebuildVehicleSpawnerMenu()
        {
            List<MenuEntry> root;
            if (!_pages.TryGetValue("VehicleSpawner", out root)) return;

            for (int i = 0; i < _vehicleCategoryPageKeys.Count; i++)
                _pages.Remove(_vehicleCategoryPageKeys[i]);
            _vehicleCategoryPageKeys.Clear();
            root.Clear();

            Dictionary<string, List<AddonVehicle>> grouped = new Dictionary<string, List<AddonVehicle>>(StringComparer.OrdinalIgnoreCase);
            List<string> categoryOrder = new List<string>();
            HashSet<string> seenModels = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // Load the master Vehicles/vehicles.json database first through _vehicleCatalog;
            // keep the separately supplied addons.json merged for backwards compatibility.
            AddVehiclesToGroups(_vehicleCatalog, grouped, categoryOrder, seenModels);
            AddVehiclesToGroups(_addonVehicles, grouped, categoryOrder, seenModels);

            root.Add(ActionEntry("Search by name / Model ID", "VehicleSearch", null, OpenVehicleSearchKeyboard));
            if (categoryOrder.Count == 0)
            {
                root.Add(new MenuEntry("No vehicle entries loaded", "Check Vehicles\\vehicles.json and addons.json.", null, null, null));
            }
            else
            {
                for (int i = 0; i < categoryOrder.Count; i++)
                {
                    string category = categoryOrder[i];
                    string pageKey = "VehicleSpawner_Category_" + i.ToString();
                    List<AddonVehicle> vehicles = grouped[category];
                    _vehicleCategoryPageKeys.Add(pageKey);
                    root.Add(PageEntry(category + " (" + vehicles.Count + ")", pageKey,
                        "Spawn vehicles from this category."));

                    List<MenuEntry> page = NewPage(pageKey);
                    for (int j = 0; j < vehicles.Count; j++)
                    {
                        AddonVehicle capturedVehicle = vehicles[j];
                        string capturedModel = capturedVehicle.model;
                        string capturedName = capturedVehicle.name;
                        page.Add(ActionEntry(capturedName, capturedModel,
                            "Spawn model: " + capturedModel,
                            delegate { BeginVehicleSpawn(capturedModel, capturedName); }));
                    }
                    page.Add(BackEntry());
                }
            }
            root.Insert(0, new MenuEntry(seenModels.Count + " unique vehicles", "Master database + preserved addons.json. Search supports names and model hashes.", null, null, null));
            root.Add(ActionEntry("Reload vehicle database", "ReloadVehicleLists", null, delegate
            {
                bool catalogLoaded = LoadVehicleCatalog();
                bool addonsLoaded = LoadAddonVehicles();
                if (catalogLoaded || addonsLoaded)
                    Notify("Vehicle lists reloaded: " + GetCombinedVehicleList().Count + " unique models.");
                else
                    Notify("Vehicle lists reload failed; previous valid lists were kept. Check scripts/YnixTrainer_Logs/errors.log.");
            }));
            root.Add(BackEntry());

            if (_currentPage != null && _currentPage.StartsWith("VehicleSpawner_Category_", StringComparison.OrdinalIgnoreCase))
            {
                _currentPage = "VehicleSpawner";
                _selectedIndex = 0;
                _scrollOffset = 0;
                _pageStack.Clear();
            }
            else if (String.Equals(_currentPage, "VehicleSpawner", StringComparison.OrdinalIgnoreCase))
            {
                _selectedIndex = 0;
                _scrollOffset = 0;
            }
            Log("Vehicle spawner rebuilt. Master database=" + _vehicleCatalog.Count +
                ", compatibility addons.json=" + _addonVehicles.Count +
                ", grouped unique models=" + seenModels.Count + ", categories=" + categoryOrder.Count);
        }

        private void OpenVehicleSearchKeyboard()
        {
            if (_vehicleSearchInputPending)
            {
                Notify("Vehicle search input is already open.");
                return;
            }

            try
            {
                _vehicleSearchInputPending = true;
                Function.Call((Hash)0x00DC833F2568DBF6UL, 0, "FMMC_KEY_TIP8", "", "", "", "", "", 64); // DISPLAY_ONSCREEN_KEYBOARD
                Notify("Enter a vehicle name, model code or model ID.");
            }
            catch (Exception ex)
            {
                _vehicleSearchInputPending = false;
                LogException("OpenVehicleSearchKeyboard", ex);
                NotifyError("Vehicle search");
            }
        }

        private void ProcessVehicleSearchInput()
        {
            int status = Function.Call<int>((Hash)0x0CF2B696BBF945AEUL); // UPDATE_ONSCREEN_KEYBOARD
            if (status == 0) return;

            _vehicleSearchInputPending = false;
            if (status != 1)
            {
                Notify("Vehicle search cancelled.");
                return;
            }

            string query = Function.Call<string>((Hash)0x8362B09B91893647UL); // GET_ONSCREEN_KEYBOARD_RESULT
            _vehicleSearchQuery = String.IsNullOrWhiteSpace(query) ? String.Empty : query.Trim();
            BuildVehicleSearchPage();
            if (!String.Equals(_currentPage, "VehicleSearch", StringComparison.OrdinalIgnoreCase))
                _pageStack.Push(_currentPage);
            _currentPage = "VehicleSearch";
            _selectedIndex = 0;
            _scrollOffset = 0;
        }

        private void BuildVehicleSearchPage()
        {
            List<MenuEntry> results = NewPage("VehicleSearch");
            string query = _vehicleSearchQuery == null ? String.Empty : _vehicleSearchQuery.Trim();
            results.Add(new MenuEntry("Query: " + (query.Length == 0 ? "(empty)" : query),
                "Matches display name, model code, decimal or hexadecimal JOAAT hash.", null, null, null));
            results.Add(ActionEntry("Search again", "SearchAgain", null, OpenVehicleSearchKeyboard));

            if (query.Length > 0)
            {
                List<AddonVehicle> allVehicles = GetCombinedVehicleList();
                string needle = query.ToLowerInvariant();
                string hashNeedle = needle.StartsWith("0x", StringComparison.Ordinal) ? needle.Substring(2) : needle;
                int added = 0;
                for (int i = 0; i < allVehicles.Count; i++)
                {
                    AddonVehicle item = allVehicles[i];
                    string name = item.name == null ? String.Empty : item.name.ToLowerInvariant();
                    string model = item.model == null ? String.Empty : item.model.ToLowerInvariant();
                    string id = item.id == null ? String.Empty : item.id.ToLowerInvariant();
                    uint unsignedHash = ComputeVehicleModelHash(item.model);
                    string decimalId = unsignedHash.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    string signedDecimalId = unchecked((int)unsignedHash).ToString(System.Globalization.CultureInfo.InvariantCulture);
                    bool match = name.IndexOf(needle, StringComparison.Ordinal) >= 0 ||
                        model.IndexOf(needle, StringComparison.Ordinal) >= 0 ||
                        id.IndexOf(hashNeedle, StringComparison.Ordinal) >= 0 ||
                        decimalId.IndexOf(needle, StringComparison.Ordinal) >= 0 ||
                        signedDecimalId.IndexOf(needle, StringComparison.Ordinal) >= 0;
                    if (!match) continue;

                    AddonVehicle found = item;
                    results.Add(new MenuEntry(found.name, found.model + "  " + found.id,
                        delegate { return found.id; }, null,
                        delegate { BeginVehicleSpawn(found.model, found.name); }));
                    added++;
                }
                results.Insert(0, new MenuEntry(added + " matches", "Select a result to spawn it.", null, null, null));
                if (added == 0)
                    results.Add(new MenuEntry("No matching vehicles", "Try a different name or model ID.", null, null, null));
            }
            else
            {
                results.Add(new MenuEntry("No query entered", "Use Search again to enter a name or model ID.", null, null, null));
            }
            results.Add(BackEntry());
        }

        private List<AddonVehicle> GetCombinedVehicleList()
        {
            List<AddonVehicle> result = new List<AddonVehicle>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            AddVehiclesToSearchList(_vehicleCatalog, result, seen);
            AddVehiclesToSearchList(_addonVehicles, result, seen);
            return result;
        }

        private void AddVehiclesToSearchList(List<AddonVehicle> source, List<AddonVehicle> destination, HashSet<string> seen)
        {
            for (int i = 0; i < source.Count; i++)
            {
                AddonVehicle item = source[i];
                if (item == null || !IsSafeVehicleModelName(item.model) || !seen.Add(item.model)) continue;
                destination.Add(item);
            }
        }

        private string FormatVehicleModelId(string modelName)
        {
            return "0x" + ComputeVehicleModelHash(modelName).ToString("X8", System.Globalization.CultureInfo.InvariantCulture);
        }

        private uint ComputeVehicleModelHash(string modelName)
        {
            // GTA uses Jenkins one-at-a-time (JOAAT) hashing over the lowercase model code.
            uint hash = 0;
            string value = (modelName ?? String.Empty).ToLowerInvariant();
            for (int i = 0; i < value.Length; i++)
            {
                hash = unchecked(hash + (byte)value[i]);
                hash = unchecked(hash + (hash << 10));
                hash ^= hash >> 6;
            }
            hash = unchecked(hash + (hash << 3));
            hash ^= hash >> 11;
            hash = unchecked(hash + (hash << 15));
            return hash;
        }

        private void AddVehiclesToGroups(List<AddonVehicle> source,
            Dictionary<string, List<AddonVehicle>> grouped,
            List<string> categoryOrder,
            HashSet<string> seenModels)
        {
            for (int i = 0; i < source.Count; i++)
            {
                AddonVehicle item = source[i];
                if (item == null || !IsSafeVehicleModelName(item.model)) continue;
                if (!seenModels.Add(item.model)) continue;

                string category = NormalizeVehicleCategory(String.IsNullOrWhiteSpace(item.category) ? "Other" : item.category);
                List<AddonVehicle> list;
                if (!grouped.TryGetValue(category, out list))
                {
                    list = new List<AddonVehicle>();
                    grouped.Add(category, list);
                    categoryOrder.Add(category);
                }
                list.Add(item);
            }
        }

        private void SpawnVehicleModel(string modelName)
        {
            BeginVehicleSpawn(modelName, modelName);
        }

        private void BeginVehicleSpawn(string modelName, string displayName)
        {
            if (_vehicleSpawnPending)
            {
                Notify("A vehicle model is already loading. Please wait.");
                return;
            }
            if (!IsSafeVehicleModelName(modelName))
            {
                Notify("Invalid vehicle model name.");
                LogFailure("Vehicle spawn", "Rejected invalid model name supplied to vehicle spawner: " + (modelName ?? "<null>"));
                Notify("Vehicle model ID is invalid. See scripts/YnixTrainer_Logs/errors.log.");
                return;
            }

            try
            {
                Model model = new Model(modelName);
                int modelHash = model.Hash;
                bool modelValid = model.IsValid;
                bool inCdImage = model.IsInCdImage;
                bool isVehicle = model.IsVehicle;
                if (!modelValid || !inCdImage || !isVehicle)
                {
                    string reason = "Vehicle model is not available in this game build: " + modelName;
                    LogFailure("Vehicle spawn", reason + " (valid=" + modelValid + ", cdimage=" + inCdImage + ", vehicle=" + isVehicle + ").");
                    Notify(reason);
                    return;
                }

                _pendingVehicleModelHash = modelHash;
                _pendingVehicleModelName = modelName;
                _pendingVehicleDisplayName = String.IsNullOrWhiteSpace(displayName) ? modelName : displayName;
                _pendingVehicleSpawnDeadlineUtc = DateTime.UtcNow.AddSeconds(15);
                _vehicleSpawnPending = true;
                Function.Call((Hash)0x963D27A58DF860ACUL, _pendingVehicleModelHash); // REQUEST_MODEL
                Notify("Loading vehicle: " + _pendingVehicleDisplayName);
                Log("Requested vehicle model: " + modelName);
            }
            catch (Exception ex)
            {
                CancelPendingVehicleSpawn();
                LogException("Begin vehicle spawn " + modelName, ex);
                Notify("Vehicle spawn could not be started. See log.");
            }
        }

        private void ProcessPendingVehicleSpawn(Ped ped)
        {
            if (!_vehicleSpawnPending) return;
            int modelHash = _pendingVehicleModelHash;
            string modelName = _pendingVehicleModelName;
            string displayName = _pendingVehicleDisplayName;

            if (DateTime.UtcNow >= _pendingVehicleSpawnDeadlineUtc)
            {
                CancelPendingVehicleSpawn();
                string timeoutReason = "Vehicle model load timed out: " + modelName;
                LogFailure("Vehicle spawn", timeoutReason);
                Notify(timeoutReason);
                return;
            }

            try
            {
                bool loaded = Function.Call<bool>((Hash)0x98A4EB5D89A0C952UL, modelHash); // HAS_MODEL_LOADED
                if (!loaded) return;
                if (ped == null || ped.Handle == 0)
                {
                    CancelPendingVehicleSpawn();
                    LogFailure("Vehicle spawn", "Player entity was unavailable when the model finished loading: " + modelName);
                    Notify("Player is not ready. Vehicle spawn cancelled.");
                    return;
                }

                Vector3 forward = Function.Call<Vector3>(Hash.GET_ENTITY_FORWARD_VECTOR, ped.Handle);
                Vector3 spawnPosition = ped.Position + forward * 8.0f;
                spawnPosition.Z += 0.5f;

                // Use CREATE_VEHICLE directly instead of the SHVDN World wrapper.
                // Model is already confirmed loaded by HAS_MODEL_LOADED above.
                int vehicleHandle = CreateVehicleEntityWithFallback(modelHash, spawnPosition, forward, ped.Heading);
                if (vehicleHandle == 0 || !Function.Call<bool>((Hash)0x7239B21A38F536BAUL, vehicleHandle))
                {
                    CancelPendingVehicleSpawn();
                    string createReason = "CREATE_VEHICLE returned no valid entity for model: " + modelName;
                    LogFailure("Vehicle spawn", createReason);
                    Notify("Vehicle could not be created: " + modelName + ". Check errors.log.");
                    return;
                }

                Function.Call((Hash)0xAD738C3085FE7E11UL, vehicleHandle, true, true); // SET_ENTITY_AS_MISSION_ENTITY
                Function.Call(Hash.SET_VEHICLE_ON_GROUND_PROPERLY, vehicleHandle);
                _trainerSpawnedVehicleHashes[vehicleHandle] = unchecked((uint)modelHash);
                Notify("Spawned vehicle: " + displayName);
                Log("Spawned vehicle: " + modelName + "; entity=" + vehicleHandle + "; hash=" + modelHash);
                CancelPendingVehicleSpawn();
            }
            catch (Exception ex)
            {
                CancelPendingVehicleSpawn();
                LogException("Process vehicle spawn " + modelName, ex);
                Notify("Vehicle spawn failed. See log.");
            }
        }

        private int CreateVehicleEntityWithFallback(int modelHash, Vector3 basePosition, Vector3 forward, float heading)
        {
            Vector3 right = new Vector3(forward.Y, -forward.X, 0.0f);
            Vector3[] positions = new Vector3[] { basePosition, basePosition + right * 5.0f,
                basePosition - right * 5.0f, basePosition + forward * 6.0f };
            for (int i = 0; i < positions.Length; i++)
            {
                Vector3 candidate = positions[i];
                int handle = Function.Call<int>((Hash)0xAF35D0D2583051B0UL,
                    modelHash, candidate.X, candidate.Y, candidate.Z, heading, false, false, false);
                if (handle != 0 && Function.Call<bool>((Hash)0x7239B21A38F536BAUL, handle))
                {
                    if (i > 0) Log("Vehicle spawn succeeded using alternate placement " + i + ".");
                    return handle;
                }
            }
            return 0;
        }

        private void ProcessDestroyedTrainerVehicles(Ped player)
        {
            List<int> removeHandles = new List<int>();
            foreach (KeyValuePair<int, uint> tracked in _trainerSpawnedVehicleHashes)
            {
                int handle = tracked.Key;
                try
                {
                    if (!Function.Call<bool>((Hash)0x7239B21A38F536BAUL, handle) ||
                        Function.Call<uint>(Hash.GET_ENTITY_MODEL, handle) != tracked.Value)
                    {
                        removeHandles.Add(handle);
                        continue;
                    }
                    bool destroyed = Function.Call<bool>((Hash)0x5F9532F3B5CC2551UL, handle, false) ||
                        Function.Call<int>(Hash.GET_ENTITY_HEALTH, handle) <= 0;
                    if (!destroyed) continue;
                    if (player != null && player.Handle != 0 && player.IsInVehicle() &&
                        player.CurrentVehicle != null && player.CurrentVehicle.Handle == handle)
                        continue;
                    Vehicle vehicle = new Vehicle(handle);
                    if (vehicle.Exists()) vehicle.Delete();
                    removeHandles.Add(handle);
                    Log("Removed destroyed vehicle spawned by trainer. Entity=" + handle + ".");
                }
                catch (Exception ex) { LogException("ProcessDestroyedTrainerVehicles " + handle, ex); }
            }
            for (int i = 0; i < removeHandles.Count; i++)
                _trainerSpawnedVehicleHashes.Remove(removeHandles[i]);
        }

        private void CancelPendingVehicleSpawn()
        {
            if (_vehicleSpawnPending && _pendingVehicleModelHash != 0)
            {
                try { Function.Call((Hash)0xE532F5D78798DAABUL, _pendingVehicleModelHash); } // SET_MODEL_AS_NO_LONGER_NEEDED
                catch (Exception ex) { LogException("Release pending vehicle model", ex); }
            }
            _vehicleSpawnPending = false;
            _pendingVehicleModelHash = 0;
            _pendingVehicleModelName = null;
            _pendingVehicleDisplayName = null;
            _pendingVehicleSpawnDeadlineUtc = DateTime.MinValue;
        }

        private string GetSelectedAddonLabel()
        {
            if (_addonVehicles.Count == 0) return "No entries";
            AddonVehicle item = _addonVehicles[_addonIndex % _addonVehicles.Count];
            return item.name + " (" + item.model + ")";
        }

        private void NextAddon()
        {
            if (_addonVehicles.Count == 0)
            {
                Notify("No vehicles in addons.json.");
                return;
            }
            _addonIndex = (_addonIndex + 1) % _addonVehicles.Count;
            Notify("Selected: " + GetSelectedAddonLabel());
        }

        private void PreviousAddon()
        {
            if (_addonVehicles.Count == 0)
            {
                Notify("No vehicles in addons.json.");
                return;
            }
            _addonIndex = (_addonIndex - 1 + _addonVehicles.Count) % _addonVehicles.Count;
            Notify("Selected: " + GetSelectedAddonLabel());
        }

        private void SpawnSelectedAddon()
        {
            if (_addonVehicles.Count == 0)
            {
                Notify("No vehicles in addons.json.");
                return;
            }

            AddonVehicle item = _addonVehicles[_addonIndex % _addonVehicles.Count];
            BeginVehicleSpawn(item.model, item.name);
        }

        private void LoadSettings()
        {
            string readPath = File.Exists(_configPath) ? _configPath : _sourceConfigPath;
            Log("Loading settings from " + readPath + (File.Exists(_configPath) ? " (Extended settings take priority over Config.ini)." : " (legacy Config.ini fallback)."));
            Dictionary<string, string> values = ReadIni(readPath);

            _settings.GodMode = GetBool(values, "PLAYER.GODMODE", true);
            _settings.AutoGiveWeapons = GetBool(values, "PLAYER.AUTOGIVEWEAPONS", true);
            _settings.InfiniteAmmo = GetBool(values, "PLAYER.INFINITEAMMO", true);
            _settings.NoReload = GetBool(values, "PLAYER.NORELOAD", true);
            _settings.NeverWanted = GetBool(values, "PLAYER.NEVERWANTED", true);
            _settings.InfiniteStamina = GetBool(values, "PLAYER.INFINITESTAMINA", true);
            _settings.UnlimitedOxygen = GetBool(values, "PLAYER.UNLIMITEDOXYGEN", true);
            _settings.FastRun = GetBool(values, "PLAYER.FASTRUN", true);
            _settings.FastSwim = GetBool(values, "PLAYER.FASTSWIM", true);
            _settings.SuperJump = GetBool(values, "PLAYER.SUPERJUMP", false);
            _settings.CopsIgnore = GetBool(values, "PLAYER.COPSIGNORE", false);
            _settings.Invisible = GetBool(values, "PLAYER.INVISIBLE", false);
            _settings.NoRagdoll = GetBool(values, "PLAYER.NORAGDOLL", false);
            _settings.VehicleGodMode = GetBool(values, "VEHICLE.VEHICLEGODMODE", true);
            _settings.Nitro = GetBool(values, "VEHICLE.NITRO", false);
            _settings.DriftMode = GetBool(values, "VEHICLE.DRIFTMODE", false);
            _settings.Speedometer = GetBool(values, "VEHICLE.SPEEDOMETER", false);
            _settings.BulletproofTires = GetBool(values, "VEHICLE.BULLETPROOFTIRES", false);
            _settings.HornJump = GetBool(values, "VEHICLE.HORNJUMP", false);
            _settings.SpeedUnitMph = GetBool(values, "VEHICLE.SPEEDUNITMPH", false);
            _settings.ExplosiveAmmo = GetBool(values, "WEAPONS.EXPLOSIVEAMMO", false);
            _settings.FireAmmo = GetBool(values, "WEAPONS.FIREAMMO", false);
            _settings.SuperDamage = GetBool(values, "WEAPONS.SUPERDAMAGE", false);
            _settings.NoClip = GetBool(values, "POWERS.NOCLIP", false);
            _settings.NightVision = GetBool(values, "POWERS.NIGHTVISION", false);
            _settings.ThermalVision = GetBool(values, "POWERS.THERMALVISION", false);
            _settings.FreezeTime = GetBool(values, "WORLD.FREEZETIME", false);
            _settings.LockWeather = GetBool(values, "WORLD.LOCKWEATHER", true);
            _settings.Weather = GetString(values, "WORLD.WEATHER", "EXTRASUNNY");
            _settings.Weather = NormalizeWeather(_settings.Weather);

            _settings.MenuWidth = ClampFloat(GetFloat(values, "MENU.WIDTH", 0.240f), 0.19f, 0.36f);
            _settings.MenuScale = ClampFloat(GetFloat(values, "MENU.SCALE", 1.0f), 0.75f, 1.30f);
            _settings.MenuRows = ClampInt(GetInt(values, "MENU.VISIBLEROWS", 9), 6, 12);
            _settings.MenuX = ClampFloat(GetFloat(values, "MENU.POSITIONX", 0.755f), 0.005f, GetMaximumMenuX());
            _settings.MenuY = ClampFloat(GetFloat(values, "MENU.POSITIONY", 0.006f), 0.005f, GetMaximumMenuY());
            _settings.MenuFontScale = ClampFloat(GetFloat(values, "MENU.FONTSCALE", 1.0f), 0.70f, 1.40f);
            _settings.MenuFontStyle = ClampInt(GetInt(values, "MENU.FONTSTYLE", 0), 0, 3);
            _settings.MenuTheme = ClampInt(GetInt(values, "MENU.THEME", 0), 0, 4);
            _settings.MenuOpacity = ClampInt(GetInt(values, "MENU.OPACITY", 225), 100, 255);
        }

        private void SaveSettings()
        {
            try
            {
                Directory.CreateDirectory(_dataDirectory);
                List<string> lines = new List<string>();
                lines.Add("; YnixTrainer Extended settings. Original Config.ini is not modified.");
                lines.Add("[PLAYER]");
                lines.Add("GODMODE=" + _settings.GodMode.ToString().ToLowerInvariant());
                lines.Add("AUTOGIVEWEAPONS=" + _settings.AutoGiveWeapons.ToString().ToLowerInvariant());
                lines.Add("INFINITEAMMO=" + _settings.InfiniteAmmo.ToString().ToLowerInvariant());
                lines.Add("NORELOAD=" + _settings.NoReload.ToString().ToLowerInvariant());
                lines.Add("NEVERWANTED=" + _settings.NeverWanted.ToString().ToLowerInvariant());
                lines.Add("INFINITESTAMINA=" + _settings.InfiniteStamina.ToString().ToLowerInvariant());
                lines.Add("UNLIMITEDOXYGEN=" + _settings.UnlimitedOxygen.ToString().ToLowerInvariant());
                lines.Add("FASTRUN=" + _settings.FastRun.ToString().ToLowerInvariant());
                lines.Add("FASTSWIM=" + _settings.FastSwim.ToString().ToLowerInvariant());
                lines.Add("SUPERJUMP=" + _settings.SuperJump.ToString().ToLowerInvariant());
                lines.Add("COPSIGNORE=" + _settings.CopsIgnore.ToString().ToLowerInvariant());
                lines.Add("INVISIBLE=" + _settings.Invisible.ToString().ToLowerInvariant());
                lines.Add("NORAGDOLL=" + _settings.NoRagdoll.ToString().ToLowerInvariant());
                lines.Add("");
                lines.Add("[WEAPONS]");
                lines.Add("EXPLOSIVEAMMO=" + _settings.ExplosiveAmmo.ToString().ToLowerInvariant());
                lines.Add("FIREAMMO=" + _settings.FireAmmo.ToString().ToLowerInvariant());
                lines.Add("SUPERDAMAGE=" + _settings.SuperDamage.ToString().ToLowerInvariant());
                lines.Add("");
                lines.Add("[POWERS]");
                lines.Add("NOCLIP=" + _settings.NoClip.ToString().ToLowerInvariant());
                lines.Add("NIGHTVISION=" + _settings.NightVision.ToString().ToLowerInvariant());
                lines.Add("THERMALVISION=" + _settings.ThermalVision.ToString().ToLowerInvariant());
                lines.Add("");
                lines.Add("[VEHICLE]");
                lines.Add("VEHICLEGODMODE=" + _settings.VehicleGodMode.ToString().ToLowerInvariant());
                lines.Add("NITRO=" + _settings.Nitro.ToString().ToLowerInvariant());
                lines.Add("DRIFTMODE=" + _settings.DriftMode.ToString().ToLowerInvariant());
                lines.Add("SPEEDOMETER=" + _settings.Speedometer.ToString().ToLowerInvariant());
                lines.Add("BULLETPROOFTIRES=" + _settings.BulletproofTires.ToString().ToLowerInvariant());
                lines.Add("HORNJUMP=" + _settings.HornJump.ToString().ToLowerInvariant());
                lines.Add("SPEEDUNITMPH=" + _settings.SpeedUnitMph.ToString().ToLowerInvariant());
                lines.Add("AUTOREPAIRVEHICLE=false");
                lines.Add("");
                lines.Add("[WORLD]");
                lines.Add("FREEZETIME=" + _settings.FreezeTime.ToString().ToLowerInvariant());
                lines.Add("LOCKWEATHER=" + _settings.LockWeather.ToString().ToLowerInvariant());
                lines.Add("WEATHER=" + _settings.Weather);
                lines.Add("");
                lines.Add("[MENU]");
                lines.Add("POSITIONX=" + _settings.MenuX.ToString("0.000", CultureInfo.InvariantCulture));
                lines.Add("POSITIONY=" + _settings.MenuY.ToString("0.000", CultureInfo.InvariantCulture));
                lines.Add("WIDTH=" + _settings.MenuWidth.ToString("0.000", CultureInfo.InvariantCulture));
                lines.Add("SCALE=" + _settings.MenuScale.ToString("0.00", CultureInfo.InvariantCulture));
                lines.Add("FONTSCALE=" + _settings.MenuFontScale.ToString("0.00", CultureInfo.InvariantCulture));
                lines.Add("FONTSTYLE=" + _settings.MenuFontStyle.ToString(CultureInfo.InvariantCulture));
                lines.Add("THEME=" + _settings.MenuTheme.ToString(CultureInfo.InvariantCulture));
                lines.Add("OPACITY=" + _settings.MenuOpacity.ToString(CultureInfo.InvariantCulture));
                lines.Add("VISIBLEROWS=" + _settings.MenuRows.ToString(CultureInfo.InvariantCulture));
                string temporaryPath = _configPath + ".tmp";
                string backupPath = _configPath + ".bak";
                File.WriteAllLines(temporaryPath, lines.ToArray());
                if (File.Exists(_configPath))
                {
                    if (File.Exists(backupPath)) File.Delete(backupPath);
                    File.Replace(temporaryPath, _configPath, backupPath);
                }
                else
                {
                    File.Move(temporaryPath, _configPath);
                }
            }
            catch (Exception ex)
            {
                LogException("SaveSettings", ex);
                Notify("Could not save settings. See log.");
            }
        }

        private Dictionary<string, string> ReadIni(string path)
        {
            Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (!File.Exists(path)) return values;
            string section = "";
            string[] lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length == 0 || line.StartsWith(";") || line.StartsWith("#")) continue;
                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    section = line.Substring(1, line.Length - 2).Trim();
                    continue;
                }
                int separator = line.IndexOf('=');
                if (separator <= 0) continue;
                string key = line.Substring(0, separator).Trim();
                string value = line.Substring(separator + 1).Trim();
                string fullKey = section + "." + key;
                if (values.ContainsKey(fullKey))
                    Log("Duplicate INI key detected in " + path + ": " + fullKey + ". The last value is used.");
                values[fullKey] = value;
            }
            return values;
        }

        private bool GetBool(Dictionary<string, string> values, string key, bool fallback)
        {
            string value;
            bool parsed;
            return values.TryGetValue(key, out value) && Boolean.TryParse(value, out parsed) ? parsed : fallback;
        }

        private int GetInt(Dictionary<string, string> values, string key, int fallback)
        {
            string value;
            int parsed;
            return values.TryGetValue(key, out value) && Int32.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) ? parsed : fallback;
        }

        private float GetFloat(Dictionary<string, string> values, string key, float fallback)
        {
            string value;
            float parsed;
            return values.TryGetValue(key, out value) && Single.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed) && !Single.IsNaN(parsed) && !Single.IsInfinity(parsed) ? parsed : fallback;
        }

        private string GetString(Dictionary<string, string> values, string key, string fallback)
        {
            string value;
            return values.TryGetValue(key, out value) && !String.IsNullOrWhiteSpace(value) ? value.Trim() : fallback;
        }

        private string NormalizeWeather(string weather)
        {
            string[] allowed = new string[] { "EXTRASUNNY", "CLEAR", "CLOUDS", "SMOG", "FOGGY", "OVERCAST", "RAIN", "THUNDER", "CLEARING", "NEUTRAL", "SNOW", "BLIZZARD", "SNOWLIGHT", "XMAS", "HALLOWEEN" };
            for (int i = 0; i < allowed.Length; i++)
                if (String.Equals(weather, allowed[i], StringComparison.OrdinalIgnoreCase)) return allowed[i];
            return "EXTRASUNNY";
        }

        private void Log(string message)
        {
            string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " [INFO] " + message + Environment.NewLine;
            AppendLogFile(_logPath, line);
            // Keep the previous 1.1.x log path populated for users upgrading in place.
            AppendLogFile(_legacyLogPath, line);
        }

        private void LogException(string context, Exception ex)
        {
            string details = ex == null ? "<no exception object>" : ex.ToString();
            LogErrorRecord(context, details, ex == null ? "null" : ex.GetType().FullName + "|" + ex.Message);
        }

        private void LogFailure(string context, string details)
        {
            LogErrorRecord(context, details, details);
        }

        private void LogErrorRecord(string context, string details, string signatureDetails)
        {
            string signature = context + "|" + (signatureDetails ?? String.Empty);
            DateTime now = DateTime.UtcNow;
            if (String.Equals(signature, _lastLoggedError, StringComparison.Ordinal) &&
                (now - _lastLoggedErrorUtc).TotalSeconds < 5.0)
                return;

            _lastLoggedError = signature;
            _lastLoggedErrorUtc = now;
            string runtimeContext = String.Empty;
            try
            {
                Ped ped = Game.Player.Character;
                if (ped != null && ped.Handle != 0)
                {
                    runtimeContext = "Player model: 0x" + Function.Call<uint>(Hash.GET_ENTITY_MODEL, ped.Handle).ToString("X8") + Environment.NewLine;
                    if (ped.IsInVehicle() && ped.CurrentVehicle != null)
                        runtimeContext += "Vehicle model: 0x" + Function.Call<uint>(Hash.GET_ENTITY_MODEL, ped.CurrentVehicle.Handle).ToString("X8") + Environment.NewLine;
                }
            }
            catch { }

            string record = Environment.NewLine + "============================================================" + Environment.NewLine +
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " [ERROR] " + context + Environment.NewLine +
                "Product: " + ProductName + " " + ProductVersion + Environment.NewLine +
                "Menu page: " + (_currentPage ?? "<none>") + "; menu open: " + _menuOpen + Environment.NewLine +
                runtimeContext + (details ?? "<no details>") + Environment.NewLine;
            AppendLogFile(_errorLogPath, record);
            AppendLogFile(_logPath, record);
            AppendLogFile(_legacyLogPath, record);
        }

        private void NotifyError(string context)
        {
            DateTime now = DateTime.UtcNow;
            if ((now - _lastErrorNotificationUtc).TotalSeconds < 5.0) return;
            _lastErrorNotificationUtc = now;
            Notify("YnixTrainer error in " + context + ". Report: scripts/YnixTrainer_Logs/errors.log");
        }

        private void AppendLogFile(string path, string content)
        {
            try
            {
                Directory.CreateDirectory(_logDirectory);
                lock (_logSync)
                {
                    using (FileStream stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    using (StreamWriter writer = new StreamWriter(stream, System.Text.Encoding.UTF8))
                    {
                        writer.Write(content);
                        writer.Flush();
                    }
                }
            }
            catch
            {
                // Logging must never crash the script. Try a simple scripts-root fallback.
                try
                {
                    string fallback = Path.Combine(_scriptsDirectory, "YnixTrainer_errors_fallback.log");
                    File.AppendAllText(fallback, content, System.Text.Encoding.UTF8);
                }
                catch { }
            }
        }

        private void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                string details = e.ExceptionObject == null ? "<null>" : e.ExceptionObject.ToString();
                string record = Environment.NewLine + "!!!!!!!!!!!!!!!! FATAL UNHANDLED EXCEPTION !!!!!!!!!!!!!!!!" + Environment.NewLine +
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + Environment.NewLine +
                    "Product: " + ProductName + " " + ProductVersion + Environment.NewLine +
                    "IsTerminating: " + e.IsTerminating + Environment.NewLine + details + Environment.NewLine;
                AppendLogFile(_crashReportPath, record);
                AppendLogFile(_errorLogPath, record);
            }
            catch { }
        }

        private void OnDomainProcessExit(object sender, EventArgs e)
        {
            Log("Game process is exiting. Last trainer session state was flushed.");
        }

        private static string[] BuildWeaponCatalog()
        {
            return new string[]
            {
                "WEAPON_KNIFE", "WEAPON_NIGHTSTICK", "WEAPON_HAMMER", "WEAPON_BAT", "WEAPON_GOLFCLUB", "WEAPON_CROWBAR", "WEAPON_BOTTLE", "WEAPON_DAGGER", "WEAPON_HATCHET", "WEAPON_KNUCKLE", "WEAPON_MACHETE", "WEAPON_FLASHLIGHT", "WEAPON_SWITCHBLADE", "WEAPON_BATTLEAXE", "WEAPON_POOLCUE", "WEAPON_WRENCH", "WEAPON_STONE_HATCHET",
                "WEAPON_PISTOL", "WEAPON_COMBATPISTOL", "WEAPON_APPISTOL", "WEAPON_PISTOL50", "WEAPON_SNSPISTOL", "WEAPON_HEAVYPISTOL", "WEAPON_VINTAGEPISTOL", "WEAPON_MARKSMANPISTOL", "WEAPON_REVOLVER", "WEAPON_DOUBLEACTION", "WEAPON_NAVYREVOLVER", "WEAPON_CERAMICPISTOL", "WEAPON_GADGETPISTOL", "WEAPON_FLAREGUN", "WEAPON_STUNGUN", "WEAPON_PISTOL_MK2", "WEAPON_SNSPISTOL_MK2", "WEAPON_REVOLVER_MK2",
                "WEAPON_MICROSMG", "WEAPON_SMG", "WEAPON_ASSAULTSMG", "WEAPON_COMBATPDW", "WEAPON_MACHINEPISTOL", "WEAPON_MINISMG", "WEAPON_SMG_MK2", "WEAPON_TECPISTOL",
                "WEAPON_PUMPSHOTGUN", "WEAPON_SAWNOFFSHOTGUN", "WEAPON_ASSAULTSHOTGUN", "WEAPON_BULLPUPSHOTGUN", "WEAPON_MUSKET", "WEAPON_HEAVYSHOTGUN", "WEAPON_DBSHOTGUN", "WEAPON_AUTOSHOTGUN", "WEAPON_PUMPSHOTGUN_MK2", "WEAPON_COMBATSHOTGUN",
                "WEAPON_ASSAULTRIFLE", "WEAPON_CARBINERIFLE", "WEAPON_ADVANCEDRIFLE", "WEAPON_SPECIALCARBINE", "WEAPON_BULLPUPRIFLE", "WEAPON_COMPACTRIFLE", "WEAPON_MILITARYRIFLE", "WEAPON_HEAVYRIFLE", "WEAPON_TACTICALRIFLE", "WEAPON_ASSAULTRIFLE_MK2", "WEAPON_CARBINERIFLE_MK2", "WEAPON_SPECIALCARBINE_MK2", "WEAPON_BULLPUPRIFLE_MK2",
                "WEAPON_MG", "WEAPON_COMBATMG", "WEAPON_GUSENBERG", "WEAPON_COMBATMG_MK2",
                "WEAPON_SNIPERRIFLE", "WEAPON_HEAVYSNIPER", "WEAPON_MARKSMANRIFLE", "WEAPON_HEAVYSNIPER_MK2", "WEAPON_MARKSMANRIFLE_MK2",
                "WEAPON_RPG", "WEAPON_GRENADELAUNCHER", "WEAPON_GRENADELAUNCHER_SMOKE", "WEAPON_MINIGUN", "WEAPON_FIREWORK", "WEAPON_RAILGUN", "WEAPON_HOMINGLAUNCHER", "WEAPON_COMPACTLAUNCHER", "WEAPON_RAYMINIGUN", "WEAPON_RAYCARBINE", "WEAPON_RAYPISTOL", "WEAPON_WIDOWMAKER", "WEAPON_UNHOLYHELLBRINGER", "WEAPON_UP_N_ATOMIZER", "WEAPON_COMPACTEMP_LAUNCHER", "WEAPON_RAILGUNXM3",
                "WEAPON_GRENADE", "WEAPON_BZGAS", "WEAPON_MOLOTOV", "WEAPON_STICKYBOMB", "WEAPON_PROXMINE", "WEAPON_SNOWBALL", "WEAPON_PIPEBOMB", "WEAPON_BALL", "WEAPON_SMOKEGRENADE", "WEAPON_FLARE",
                "WEAPON_FIREEXTINGUISHER", "WEAPON_PETROLCAN", "WEAPON_HAZARDCAN", "WEAPON_FERTILIZERCAN", "WEAPON_PARACHUTE"
            };
        }

        private static string[] BuildWeaponComponentCatalog()
        {
            return new string[]
            {
                "COMPONENT_AT_PI_FLSH", "COMPONENT_AT_PI_SUPP_02", "COMPONENT_AT_PI_SUPP", "COMPONENT_AT_PI_COMP",
                "COMPONENT_AT_AR_FLSH", "COMPONENT_AT_AR_SUPP", "COMPONENT_AT_AR_SUPP_02", "COMPONENT_AT_AR_AFGRIP",
                "COMPONENT_AT_SCOPE_MACRO", "COMPONENT_AT_SCOPE_SMALL", "COMPONENT_AT_SCOPE_MEDIUM", "COMPONENT_AT_SCOPE_LARGE", "COMPONENT_AT_SCOPE_MAX", "COMPONENT_AT_SCOPE_NV", "COMPONENT_AT_SCOPE_THERMAL",
                "COMPONENT_AT_MUZZLE_01", "COMPONENT_AT_MUZZLE_02", "COMPONENT_AT_MUZZLE_03", "COMPONENT_AT_MUZZLE_04", "COMPONENT_AT_MUZZLE_05", "COMPONENT_AT_MUZZLE_06", "COMPONENT_AT_MUZZLE_07", "COMPONENT_AT_MUZZLE_08", "COMPONENT_AT_MUZZLE_09", "COMPONENT_AT_MUZZLE_10", "COMPONENT_AT_MUZZLE_11", "COMPONENT_AT_MUZZLE_12", "COMPONENT_AT_MUZZLE_13", "COMPONENT_AT_MUZZLE_14", "COMPONENT_AT_MUZZLE_15", "COMPONENT_AT_MUZZLE_16", "COMPONENT_AT_MUZZLE_17",
                "COMPONENT_PISTOL_MK2_CLIP_02", "COMPONENT_SNSPISTOL_MK2_CLIP_02",
                "COMPONENT_SMG_MK2_CLIP_02", "COMPONENT_ASSAULTRIFLE_MK2_CLIP_02",
                "COMPONENT_CARBINERIFLE_MK2_CLIP_02", "COMPONENT_SPECIALCARBINE_MK2_CLIP_02", "COMPONENT_BULLPUPRIFLE_MK2_CLIP_02", "COMPONENT_COMBATMG_MK2_CLIP_02", "COMPONENT_MARKSMANRIFLE_MK2_CLIP_02", "COMPONENT_HEAVYSNIPER_MK2_CLIP_02",
                "COMPONENT_PISTOL_VARMOD_LUXE", "COMPONENT_APPISTOL_VARMOD_LUXE", "COMPONENT_PISTOL50_VARMOD_LUXE", "COMPONENT_HEAVYPISTOL_VARMOD_LUXE", "COMPONENT_MICROSMG_VARMOD_LUXE", "COMPONENT_SMG_VARMOD_LUXE", "COMPONENT_ASSAULTSMG_VARMOD_LOWRIDER", "COMPONENT_ASSAULTRIFLE_VARMOD_LUXE", "COMPONENT_CARBINERIFLE_VARMOD_LUXE", "COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE", "COMPONENT_SPECIALCARBINE_VARMOD_LOWRIDER", "COMPONENT_BULLPUPRIFLE_VARMOD_LOW", "COMPONENT_MG_VARMOD_LOWRIDER", "COMPONENT_COMBATMG_VARMOD_LOWRIDER", "COMPONENT_PUMPSHOTGUN_VARMOD_LOWRIDER", "COMPONENT_SNIPERRIFLE_VARMOD_LUXE", "COMPONENT_MARKSMANRIFLE_VARMOD_LUXE",
                "COMPONENT_PISTOL_MK2_VARMOD_LUXE", "COMPONENT_SNSPISTOL_MK2_VARMOD_LUXE", "COMPONENT_REVOLVER_MK2_VARMOD_BOSS", "COMPONENT_REVOLVER_MK2_VARMOD_GOON", "COMPONENT_SMG_MK2_VARMOD_LUXE", "COMPONENT_PUMPSHOTGUN_MK2_VARMOD_LUXE", "COMPONENT_ASSAULTRIFLE_MK2_VARMOD_LUXE", "COMPONENT_CARBINERIFLE_MK2_VARMOD_LUXE", "COMPONENT_SPECIALCARBINE_MK2_VARMOD_LOWRIDER", "COMPONENT_BULLPUPRIFLE_MK2_VARMOD_LUXE", "COMPONENT_COMBATMG_MK2_VARMOD_LUXE", "COMPONENT_MARKSMANRIFLE_MK2_VARMOD_LUXE", "COMPONENT_HEAVYSNIPER_MK2_VARMOD_LUXE",
                "COMPONENT_PISTOL_CLIP_02", "COMPONENT_COMBATPISTOL_CLIP_02", "COMPONENT_APPISTOL_CLIP_02", "COMPONENT_PISTOL50_CLIP_02", "COMPONENT_SNSPISTOL_CLIP_02", "COMPONENT_HEAVYPISTOL_CLIP_02", "COMPONENT_VINTAGEPISTOL_CLIP_02",
                "COMPONENT_MICROSMG_CLIP_02", "COMPONENT_SMG_CLIP_02", "COMPONENT_ASSAULTSMG_CLIP_02", "COMPONENT_COMBATPDW_CLIP_02", "COMPONENT_MACHINEPISTOL_CLIP_02", "COMPONENT_MINISMG_CLIP_02",
                "COMPONENT_ASSAULTRIFLE_CLIP_02", "COMPONENT_CARBINERIFLE_CLIP_02", "COMPONENT_ADVANCEDRIFLE_CLIP_02", "COMPONENT_SPECIALCARBINE_CLIP_02", "COMPONENT_BULLPUPRIFLE_CLIP_02", "COMPONENT_COMPACTRIFLE_CLIP_02",
                "COMPONENT_ASSAULTRIFLE_CLIP_03", "COMPONENT_CARBINERIFLE_CLIP_03",
                "COMPONENT_SPECIALCARBINE_CLIP_03", "COMPONENT_COMPACTRIFLE_CLIP_03",
                "COMPONENT_MG_CLIP_02", "COMPONENT_COMBATMG_CLIP_02", "COMPONENT_GUSENBERG_CLIP_02", "COMPONENT_PUMPSHOTGUN_CLIP_02", "COMPONENT_ASSAULTSHOTGUN_CLIP_02", "COMPONENT_BULLPUPSHOTGUN_CLIP_02", "COMPONENT_HEAVYSHOTGUN_CLIP_02",
                "COMPONENT_SNIPERRIFLE_CLIP_02", "COMPONENT_HEAVYSNIPER_CLIP_02", "COMPONENT_MARKSMANRIFLE_CLIP_02", "COMPONENT_GRENADELAUNCHER_CLIP_02"
            };
        }

        private sealed class WeaponSnapshot
        {
            public readonly uint Hash;
            public readonly int Ammo;

            public WeaponSnapshot(uint hash, int ammo)
            {
                Hash = hash;
                Ammo = ammo;
            }
        }

        public sealed class FavoriteLocation
        {
            public string name { get; set; }
            public float x { get; set; }
            public float y { get; set; }
            public float z { get; set; }
        }

        private sealed class TrainerSettings
        {
            public bool GodMode = true;
            public bool AutoGiveWeapons = true;
            public bool InfiniteAmmo = true;
            public bool NoReload = true;
            public bool NeverWanted = true;
            public bool InfiniteStamina = true;
            public bool UnlimitedOxygen = true;
            public bool FastRun = true;
            public bool FastSwim = true;
            public bool SuperJump = false;
            public bool CopsIgnore = false;
            public bool Invisible = false;
            public bool NoRagdoll = false;
            public bool ExplosiveAmmo = false;
            public bool FireAmmo = false;
            public bool SuperDamage = false;
            public bool VehicleGodMode = true;
            public bool Nitro = false;
            public bool DriftMode = false;
            public bool Speedometer = false;
            public bool BulletproofTires = false;
            public bool HornJump = false;
            public bool SpeedUnitMph = false;
            public bool NoClip = false;
            public bool NightVision = false;
            public bool ThermalVision = false;
            public bool FreezeTime = false;
            public bool LockWeather = true;
            public string Weather = "EXTRASUNNY";
            public float MenuX = 0.755f;
            public float MenuY = 0.006f;
            public float MenuWidth = 0.240f;
            public float MenuScale = 1.0f;
            public float MenuFontScale = 1.0f;
            public int MenuFontStyle = 0;
            public int MenuTheme = 0;
            public int MenuOpacity = 225;
            public int MenuRows = 9;
        }

        private sealed class MenuEntry
        {
            public readonly string Title;
            public readonly string Description;
            public readonly Func<string> Value;
            public readonly string ChildPage;
            public readonly Action Action;

            public MenuEntry(string title, string description, Func<string> value, string childPage, Action action)
            {
                Title = title;
                Description = description;
                Value = value;
                ChildPage = childPage;
                Action = action;
            }
        }

        public sealed class AddonVehicle
        {
            public string name { get; set; }
            public string model { get; set; }
            public string id { get; set; }
            public string category { get; set; }
            public string source { get; set; }
        }
    }
}
