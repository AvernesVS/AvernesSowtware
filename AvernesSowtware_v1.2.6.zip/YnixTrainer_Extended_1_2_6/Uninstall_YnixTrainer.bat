@echo off
setlocal EnableExtensions DisableDelayedExpansion
title YnixTrainer Extended 1.2.6 Uninstaller
set "UNINSTALL_LOG=%TEMP%\YnixTrainer_Uninstall.log"
if /i "%~2"=="--elevated" (
  call :log "Uninstaller resumed with elevated permissions."
) else (
  >"%UNINSTALL_LOG%" echo YnixTrainer Extended 1.2.6 uninstall log
)
set "GTAV_DIR=%~1"
if not defined GTAV_DIR set "GTAV_DIR=C:\Program Files (x86)\Grand Theft Auto V"
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
if not exist "%GTAV_DIR%\scripts" call :prompt_game_path
if not exist "%GTAV_DIR%\scripts" (
  set "FAIL_REASON=GTA V scripts folder was not found."
  goto :fail
)
set "SCRIPTS_DIR=%GTAV_DIR%\scripts"
set "BACKUP_DIR=%SCRIPTS_DIR%\YnixTrainer_Backups"
set "WRITE_TEST_FILE=%SCRIPTS_DIR%\.__ynix_uninstall_write_test_%RANDOM%_%RANDOM%.tmp"
>"%WRITE_TEST_FILE%" echo YnixTrainer uninstall write test 2>>"%UNINSTALL_LOG%"
if errorlevel 1 goto :request_elevation
del /f /q "%WRITE_TEST_FILE%" >>"%UNINSTALL_LOG%" 2>&1
if exist "%WRITE_TEST_FILE%" (
  set "FAIL_REASON=Temporary write-test file could not be removed."
  goto :fail
)
set "RESTORE_SOURCE="
rem Restore the newest previous DLL backup, regardless of the installed release number.
for /f "delims=" %%F in ('dir /b /a-d /o-d "%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_*.bak" 2^>nul') do if not defined RESTORE_SOURCE set "RESTORE_SOURCE=%BACKUP_DIR%\%%F"
if defined RESTORE_SOURCE goto :restore_previous
goto :remove_current
:restore_previous
call :log "Restoring previous DLL from %RESTORE_SOURCE%"
set "RESTORE_STAGE=%SCRIPTS_DIR%\YnixTrainerExtended.dll.restore.new"
if exist "%RESTORE_STAGE%" del /f /q "%RESTORE_STAGE%" >>"%UNINSTALL_LOG%" 2>&1
if exist "%RESTORE_STAGE%" (
  set "FAIL_REASON=Could not clear stale restore staging file: %RESTORE_STAGE%"
  goto :fail
)
copy /b /y "%RESTORE_SOURCE%" "%RESTORE_STAGE%" >>"%UNINSTALL_LOG%" 2>&1
if errorlevel 1 (
  set "FAIL_REASON=Could not stage the backup DLL for restoration."
  goto :fail
)
for %%I in ("%RESTORE_SOURCE%") do set "BACKUP_SIZE=%%~zI"
for %%I in ("%RESTORE_STAGE%") do set "RESTORE_SIZE=%%~zI"
if not "%BACKUP_SIZE%"=="%RESTORE_SIZE%" (
  set "FAIL_REASON=Restoration staging size mismatch; the installed DLL was not changed."
  goto :fail
)
move /y "%RESTORE_STAGE%" "%SCRIPTS_DIR%\YnixTrainerExtended.dll" >>"%UNINSTALL_LOG%" 2>&1
if errorlevel 1 (
  set "FAIL_REASON=Could not replace the current DLL with the staged backup. Close GTA V and retry."
  goto :fail
)
for %%I in ("%SCRIPTS_DIR%\YnixTrainerExtended.dll") do set "FINAL_SIZE=%%~zI"
if not "%BACKUP_SIZE%"=="%FINAL_SIZE%" (
  set "FAIL_REASON=Restored DLL size verification failed."
  goto :fail
)
set "RESULT_MESSAGE=Previous DLL restored successfully."
goto :cleanup
:remove_current
if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll" (
  del /f /q "%SCRIPTS_DIR%\YnixTrainerExtended.dll" >>"%UNINSTALL_LOG%" 2>&1
  if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll" (
    set "FAIL_REASON=Could not remove the trainer DLL. Close GTA V and check file permissions."
    goto :fail
  )
  set "RESULT_MESSAGE=Trainer DLL removed. No previous DLL backup was found."
) else (
  set "RESULT_MESSAGE=Trainer DLL was already absent. No previous DLL backup was found."
)
:cleanup
if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" (
  del /f /q "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" >>"%UNINSTALL_LOG%" 2>&1
  if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" (
    set "FAIL_REASON=Trainer DLL was handled, but the temporary .new file could not be removed."
    goto :fail
  )
)
call :log "%RESULT_MESSAGE%"
echo.
echo [SUCCESS] %RESULT_MESSAGE%
echo User settings, vehicle JSON, logs and backup files in scripts\YnixTrainer* were preserved.
echo Uninstall log: "%UNINSTALL_LOG%"
pause
exit /b 0
:request_elevation
if /i "%~2"=="--elevated" (
  set "FAIL_REASON=Windows denied write access even after elevation. Check permissions or security software."
  goto :fail
)
call :log "Write access denied. Requesting administrator approval."
set "ELEVATE_SCRIPT=%~f0"
set "ELEVATE_GAME=%GTAV_DIR%"
set "ELEVATE_ARGS=/d /c ""%ELEVATE_SCRIPT%"" ""%ELEVATE_GAME%"" --elevated"
set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" set "PS_EXE=powershell.exe"
"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath $env:ComSpec -ArgumentList $env:ELEVATE_ARGS -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
set "ELEVATE_RC=%ERRORLEVEL%"
if not "%ELEVATE_RC%"=="0" (
  set "FAIL_REASON=Administrator approval was cancelled or the elevated uninstaller failed (exit code %ELEVATE_RC%)."
  goto :fail
)
call :log "Elevated uninstaller finished with exit code 0."
exit /b 0
:prompt_game_path
echo GTA V scripts folder was not found in the default location.
set "GTAV_DIR="
set /p "GTAV_DIR=Enter GTA V root folder: "
if not defined GTAV_DIR exit /b 1
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
exit /b 0
:log
>>"%UNINSTALL_LOG%" echo [%DATE% %TIME%] %*
exit /b 0
:fail
call :log "ERROR: %FAIL_REASON%"
echo.
echo [ERROR] Uninstall did not complete.
echo Reason: %FAIL_REASON%
echo User settings and backup files have not been intentionally deleted.
echo Uninstall log: "%UNINSTALL_LOG%"
pause
exit /b 1
