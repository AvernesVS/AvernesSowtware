# Проверки AvernesSowtware 1.3.6

Автоматические проверки Windows CI:
- компиляция C# 4 / .NET Framework 4.0 API с ScriptHookVDotNet2;
- ReleaseValidator и проверка состава ZIP;
- регрессионные проверки Never Wanted (нет глобального ignore и отключения Army dispatch), bodyguard damage/vitals/seat reservations/blips/aim weapon, population density, Nitro ceiling, Vehicle God Mode repair;
- повторная установка и сохранение пользовательских данных.

Не подтверждается статическими тестами: реальное поведение NPC/армии/ПВО, плотность воздушного трафика, физика разгона и отсутствие видимых повреждений в GTA V. Требуется ручная проверка в GTA V Legacy Story Mode.
