# Проверка AvernesSowtware 1.3.2

- База: AvernesSowtware 1.3.1 release archive.
- Проверяемые изменения: UI, Heavy Sniper Mk II thermal optic, class-based wheel families, maximum tint, matte paint preservation.
- Компиляция и статические проверки: выполняются текущим Windows CI.
- GTA V Legacy runtime: не автоматизирован; требуется ручная проверка в Story Mode.
