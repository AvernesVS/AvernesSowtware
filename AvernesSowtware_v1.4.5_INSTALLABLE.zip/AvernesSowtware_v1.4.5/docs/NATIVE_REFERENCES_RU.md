﻿# Native references used by Max Tuning

The implementation uses the following GTA V vehicle natives:

| Native | Hash | Purpose |
|---|---|---|
| SET_VEHICLE_MOD_KIT | `0x1F2AA07F00B3217A` | Assign mod kit 0 before querying or applying parts |
| GET_NUM_VEHICLE_MODS | `0xE38E9162A2500646` | Read the available count for a slot |
| SET_VEHICLE_MOD | `0x6AF0636DDEDCB6DD` | Apply the highest available index in a normal slot |
| GET_VEHICLE_MOD | `0x772960298DA26FDB` | Verify the selected index |
| TOGGLE_VEHICLE_MOD | `0x2A1F4F37F95BAD08` | Enable turbo, tyre smoke and xenon |
| IS_TOGGLE_MOD_ON | `0x84B233A8C8FC8AE7` | Verify toggle state |
| GET_VEHICLE_LIVERY_COUNT | `0x87B63E25A529D526` | Detect texture livery availability |
| SET_VEHICLE_LIVERY | `0x60BF608F1B8CD1B6` | Apply the highest texture livery |

The three toggle-only mod types used here are 18 (turbo), 20 (tyre smoke), and 22 (xenon lights). Other available mod slots in the 0–49 range are queried and set as indexed mods. A vehicle without a compatible mod kit may expose no available slots.

References:
- https://github.com/citizenfx/natives/blob/master/VEHICLE/SetVehicleMod.md
- https://cfxnatives.dev/natives/GET_NUM_VEHICLE_MODS
- https://cfxnatives.dev/natives/IS_TOGGLE_MOD_ON
- https://cfxnatives.dev/natives/GET_VEHICLE_LIVERY_COUNT


## Additional native references used in 1.2.8

### Anti-eject

| Native | Hash | Use |
|---|---|---|
| GET_PED_CONFIG_FLAG | `0x7EE53118C892B513` | Read and preserve player config flag 32. |
| SET_PED_CONFIG_FLAG | `0x1913FE4CBF41C463` | Toggle flag 32, `WillFlyThroughWindscreen`. |
| SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE | `0x7A6535691B477C48` | Set state `1` (`NEVER`) while Anti-Eject is active. |

Flag 32 is restored to its captured value when the feature is disabled or the player leaves the vehicle. The knock-off state is returned to the normal/default state (`0`), not an invented saved state.

References:
- https://github.com/citizenfx/natives/blob/master/PED/GetPedConfigFlag.md
- https://github.com/citizenfx/natives/blob/master/PED/SetPedConfigFlag.md
- https://github.com/citizenfx/natives/blob/master/PED/SetPedCanBeKnockedOffVehicle.md

### Motorcycles and wheel slots

- `GET_VEHICLE_CLASS` (`0x29439776AAA00A62`) returns class `8` for motorcycles.
- `SET_VEHICLE_WHEEL_TYPE` (`0x487EB21CC7295BA1`) uses type `6` for Bike Wheels.
- Slot `23` is the front motorcycle wheel; slot `24` is the rear wheel.
- `SET_VEHICLE_MOD` receives the custom-tyre variation flag for bike wheel assets; the implementation enables it for motorcycles and keeps the original car behavior for other vehicles.

References:
- https://cfxnatives.dev/natives/GET_VEHICLE_CLASS
- https://gtahash.com/vehicle-mods/wheels
- https://gtahash.com/vehicle-mods/wheels/wheel_bkf_24
- https://gtahash.com/vehicle-mods/wheels/wheel_bkr_24

### Helicopter rocket fire mode

| Native | Hash | Use |
|---|---|---|
| HAS_WEAPON_ASSET_LOADED | `0x36E353271F0E90EE` | Check the rocket asset before firing. |
| REQUEST_WEAPON_ASSET | `0x5443438F033E29C3` | Request `WEAPON_VEHICLE_ROCKET` asset. |
| SHOOT_SINGLE_BULLET_BETWEEN_COORDS | `0x867654CBC7606F2C` | Fire two rocket projectiles from the helicopter. |

This is a separately activated projectile mode (`Numpad +`), not a native vehicle weapon mod-slot installation.

Reference implementation pattern:
- https://github.com/croced/GTA-V-Improved-Trainer/blob/master/samples/NativeTrainer/script.cpp

### Tint, speed and character variation

- `SET_VEHICLE_WINDOW_TINT` (`0x57C51E6BAD752696`): `WINDOWTINT_LIMO = 5`.
- `GET_VEHICLE_PED_IS_IN` (`0x9A9112A0FE9A4713`) requires both `ped` and `lastVehicle`; `false` requests the current vehicle.
- `SET_VEHICLE_FORWARD_SPEED` (`0xAB54A438726D25D5`) takes metres per second.
- Wardrobe uses `GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS` (`0x27561561732A7842`), `GET_NUMBER_OF_PED_TEXTURE_VARIATIONS` (`0x8F7156A3142A6BAD`), `IS_PED_COMPONENT_VARIATION_VALID` (`0xE825F6B6CEA7671D`) and `SET_PED_COMPONENT_VARIATION` (`0x262B14F48D29DE80`).
- Parachute reset uses the player clear-override natives and `CLEAR_PED_PARACHUTE_PACK_VARIATION` (`0x1280804F7CFD2D6C`); it cannot repair damaged game archive textures.

References:
- https://github.com/citizenfx/natives/blob/master/VEHICLE/SetVehicleWindowTint.md
- https://github.com/citizenfx/natives/blob/master/PED/GetVehiclePedIsIn.md
- https://github.com/citizenfx/natives/blob/master/VEHICLE/SetVehicleForwardSpeed.md
- https://github.com/citizenfx/natives/blob/master/PED/GetNumberOfPedDrawableVariations.md
- https://github.com/citizenfx/natives/blob/master/PED/SetPedComponentVariation.md
- https://github.com/citizenfx/natives/blob/master/PLAYER/ClearPlayerParachuteModelOverride.md
