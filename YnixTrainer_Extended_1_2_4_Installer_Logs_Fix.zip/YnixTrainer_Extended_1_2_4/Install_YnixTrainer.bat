@echo off
setlocal EnableExtensions DisableDelayedExpansion

cd /d "%~dp0" || goto :project_dir_fail
set "PROJECT_DIR=%CD%"
set "INSTALL_LOG=%PROJECT_DIR%\YnixTrainer_Install.log"
>"%INSTALL_LOG%" echo YnixTrainer Extended 1.2.4 installation log
if errorlevel 1 call :use_temp_log
call :log "Installer started. Project directory: %PROJECT_DIR%"

set "GTAV_DIR=%~1"
if not defined GTAV_DIR set "GTAV_DIR=C:\Program Files (x86)\Grand Theft Auto V"
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
call :find_shvdn
if not defined SHVDN_DLL call :prompt_game_path
if not defined SHVDN_DLL (
  set "FAIL_REASON=ScriptHookVDotNet2.dll was not found in GTA V root or scripts folder, or no valid path was entered."
  goto :fail
)
call :log "GTA V directory: %GTAV_DIR%"
call :log "ScriptHookVDotNet2 reference: %SHVDN_DLL%"

set "SOURCE_DLL=%PROJECT_DIR%\dist\YnixTrainerExtended.dll"
if not exist "%SOURCE_DLL%" (
  set "FAIL_REASON=Compiled DLL is missing at %SOURCE_DLL%. Run build\Build.bat first."
  goto :fail
)

set "SCRIPTS_DIR=%GTAV_DIR%\scripts"
set "DATA_DIR=%SCRIPTS_DIR%\YnixTrainer"
set "VEHICLES_DIR=%DATA_DIR%\Vehicles"
set "LOG_DIR=%SCRIPTS_DIR%\YnixTrainer_Logs"
set "BACKUP_DIR=%SCRIPTS_DIR%\YnixTrainer_Backups"

rem Validate the complete package before writing anything to the game folder.
for %%F in (
  "%PROJECT_DIR%\package\YnixTrainer\YnixTrainerExtended.ini"
  "%PROJECT_DIR%\package\YnixTrainer\addons.json"
  "%PROJECT_DIR%\package\YnixTrainer\favorite_locations.json"
  "%PROJECT_DIR%\package\YnixTrainer\Vehicles\vehicles.json"
  "%PROJECT_DIR%\package\YnixTrainer\vehicle_catalog.json"
  "%PROJECT_DIR%\package\YnixTrainer\Vehicles\README.txt"
) do (
  if not exist "%%~fF" (
    set "FAIL_REASON=Required packaged file is missing: %%~fF"
    goto :fail
  )
  if %%~zF LEQ 0 (
    set "FAIL_REASON=Required packaged file is empty: %%~fF"
    goto :fail
  )
)

call :ensure_dir "%SCRIPTS_DIR%" "scripts directory"
if errorlevel 1 goto :fail
call :ensure_dir "%DATA_DIR%" "YnixTrainer data directory"
if errorlevel 1 goto :fail
call :ensure_dir "%VEHICLES_DIR%" "Vehicles directory"
if errorlevel 1 goto :fail
call :ensure_dir "%BACKUP_DIR%" "backup directory"
if errorlevel 1 goto :fail
call :ensure_dir "%LOG_DIR%" "logs directory"
if errorlevel 1 goto :fail
call :log "Required installation directories are ready."

rem Copy only missing defaults. Existing custom files/settings are never overwritten.
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\YnixTrainerExtended.ini" "%DATA_DIR%\YnixTrainerExtended.ini" "Extended settings"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\addons.json" "%DATA_DIR%\addons.json" "add-on list"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\favorite_locations.json" "%DATA_DIR%\favorite_locations.json" "favorite locations"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\Vehicles\vehicles.json" "%VEHICLES_DIR%\vehicles.json" "main vehicle database"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\Vehicles\vehicles.json" "%VEHICLES_DIR%\vehicles_builtin.json" "built-in vehicle fallback"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\vehicle_catalog.json" "%VEHICLES_DIR%\vehicle_catalog.json" "vehicle compatibility database"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\addons.json" "%DATA_DIR%\addons_builtin.json" "built-in add-on fallback"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\vehicle_catalog.json" "%DATA_DIR%\vehicle_catalog.json" "legacy vehicle compatibility database"
if errorlevel 1 goto :fail
call :copy_if_missing "%PROJECT_DIR%\package\YnixTrainer\Vehicles\README.txt" "%VEHICLES_DIR%\README.txt" "vehicle database notes"
if errorlevel 1 goto :fail

rem Stage the new DLL; preserve the existing DLL before replacing it.
copy /y "%SOURCE_DLL%" "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" >nul
if errorlevel 1 (
  set "FAIL_REASON=Could not stage the new DLL in scripts."
  goto :fail
)
if not exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" (
  set "FAIL_REASON=Staged DLL was not created."
  goto :fail
)

set "BACKUP_FILE=%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_4.bak"
set /a BACKUP_INDEX=2
:backup_loop
if exist "%BACKUP_FILE%" (
  if %BACKUP_INDEX% GTR 50 (
    set "FAIL_REASON=Could not choose a unique backup filename for the current DLL."
    goto :fail
  )
  set "BACKUP_FILE=%BACKUP_DIR%\YnixTrainerExtended.dll.pre_1_2_4_%BACKUP_INDEX%.bak"
  set /a BACKUP_INDEX+=1
  goto :backup_loop
)
if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll" (
  copy /y "%SCRIPTS_DIR%\YnixTrainerExtended.dll" "%BACKUP_FILE%" >nul
  if errorlevel 1 (
    set "FAIL_REASON=Could not back up the current root DLL."
    goto :fail
  )
  call :log "Previous root DLL backed up to %BACKUP_FILE%"
)
move /y "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" "%SCRIPTS_DIR%\YnixTrainerExtended.dll" >nul
if errorlevel 1 (
  set "FAIL_REASON=Could not move staged DLL into scripts root."
  goto :fail
)

rem Relocate the misplaced DLL reported in scripts\YnixTrainer without deleting it.
if exist "%DATA_DIR%\YnixTrainerExtended.dll" call :relocate_misplaced_dll
if errorlevel 1 goto :fail

if not exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll" (
  set "FAIL_REASON=Main DLL is missing after installation."
  goto :fail
)
if not exist "%VEHICLES_DIR%\vehicles.json" (
  set "FAIL_REASON=Vehicle database is missing after installation."
  goto :fail
)
if not exist "%VEHICLES_DIR%\vehicles_builtin.json" (
  set "FAIL_REASON=Built-in vehicle fallback is missing after installation."
  goto :fail
)
if not exist "%DATA_DIR%\addons.json" (
  set "FAIL_REASON=Add-on JSON is missing after installation."
  goto :fail
)
if not exist "%DATA_DIR%\addons_builtin.json" (
  set "FAIL_REASON=Built-in add-on fallback is missing after installation."
  goto :fail
)

call :log "SUCCESS: Main DLL, runtime data, and fallback databases installed."
>>"%LOG_DIR%\install.log" echo [%DATE% %TIME%] Installation completed. Full log: %INSTALL_LOG%
>>"%LOG_DIR%\install.log" type "%INSTALL_LOG%"
echo.
echo [SUCCESS] YnixTrainer Extended 1.2.4 installed.
echo Main DLL: "%SCRIPTS_DIR%\YnixTrainerExtended.dll"
echo Vehicle DB: "%VEHICLES_DIR%\vehicles.json"
echo Install log: "%INSTALL_LOG%"
echo Runtime logs: "%LOG_DIR%\session.log" and "%LOG_DIR%\errors.log"
echo Existing and misplaced DLL copies, if any, were preserved in "%BACKUP_DIR%".
echo Close and restart GTA V Story Mode to load the new version.
exit /b 0

:use_temp_log
set "INSTALL_LOG=%TEMP%\YnixTrainer_Install.log"
>"%INSTALL_LOG%" echo YnixTrainer Extended 1.2.4 installation log
exit /b 0

:prompt_game_path
echo ScriptHookVDotNet2.dll was not found in the default GTA V location.
echo It may be in either the GTA V root or the scripts folder.
set "GTAV_DIR="
set /p "GTAV_DIR=Enter GTA V root folder: "
if not defined GTAV_DIR exit /b 1
set "GTAV_DIR=%GTAV_DIR:"=%"
for %%I in ("%GTAV_DIR%") do set "GTAV_DIR=%%~fI"
call :find_shvdn
if not defined SHVDN_DLL exit /b 1
exit /b 0

:find_shvdn
set "SHVDN_DLL="
if exist "%GTAV_DIR%\ScriptHookVDotNet2.dll" set "SHVDN_DLL=%GTAV_DIR%\ScriptHookVDotNet2.dll"
if not defined SHVDN_DLL if exist "%GTAV_DIR%\scripts\ScriptHookVDotNet2.dll" set "SHVDN_DLL=%GTAV_DIR%\scripts\ScriptHookVDotNet2.dll"
exit /b 0

:ensure_dir
if exist "%~1" exit /b 0
mkdir "%~1" >nul 2>&1
if errorlevel 1 (
  set "FAIL_REASON=Cannot create %~2: %~1"
  exit /b 1
)
exit /b 0

:copy_if_missing
if exist "%~2" exit /b 0
copy /y "%~1" "%~2" >nul
if errorlevel 1 (
  set "FAIL_REASON=Could not install %~3 from %~1 to %~2"
  exit /b 1
)
call :log "Installed missing %~3: %~2"
exit /b 0

:relocate_misplaced_dll
call :make_nested_backup_name
if errorlevel 1 (
  set "FAIL_REASON=Could not choose a backup filename for the misplaced DLL."
  exit /b 1
)
move /y "%DATA_DIR%\YnixTrainerExtended.dll" "%NESTED_BACKUP%" >nul
if errorlevel 1 (
  set "FAIL_REASON=The misplaced data-folder DLL could not be moved to the backup folder."
  exit /b 1
)
call :log "Misplaced DLL preserved in backup: %NESTED_BACKUP%"
exit /b 0

:make_nested_backup_name
set "NESTED_BACKUP=%BACKUP_DIR%\YnixTrainerExtended.dll.misplaced.pre_1_2_4.bak"
set /a NESTED_INDEX=2
:make_nested_backup_name_loop
if exist "%NESTED_BACKUP%" (
  if %NESTED_INDEX% GTR 50 exit /b 1
  set "NESTED_BACKUP=%BACKUP_DIR%\YnixTrainerExtended.dll.misplaced.pre_1_2_4_%NESTED_INDEX%.bak"
  set /a NESTED_INDEX+=1
  goto :make_nested_backup_name_loop
)
exit /b 0

:log
>>"%INSTALL_LOG%" echo [%DATE% %TIME%] %*
exit /b 0

:project_dir_fail
echo [ERROR] Could not enter the installer project directory.
pause
exit /b 1

:fail
if defined INSTALL_LOG call :log "ERROR: %FAIL_REASON%"
if defined SCRIPTS_DIR if exist "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" del /q "%SCRIPTS_DIR%\YnixTrainerExtended.dll.new" >nul 2>&1
echo.
echo [ERROR] Installation did not complete.
if defined FAIL_REASON echo Reason: %FAIL_REASON%
if defined INSTALL_LOG echo Installation log: "%INSTALL_LOG%"
echo Existing user settings and JSON files were not intentionally deleted.
pause
exit /b 1
