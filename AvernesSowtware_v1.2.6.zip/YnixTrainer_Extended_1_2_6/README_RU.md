# YnixTrainer Extended 1.2.6

## Состав архива
- `src/YnixTrainerExtended.cs` — исходный код трейнера.
- `package/YnixTrainer/Vehicles/vehicles.json` — основная база транспорта (469 записей).
- `package/YnixTrainer/vehicle_catalog.json` — совместимая копия базы для старого расположения файла.
- `package/YnixTrainer/addons.json` — переданный список Add-on записей (85 записей).
- `package/YnixTrainer/YnixTrainerExtended.ini` — начальная конфигурация.
- `package/YnixTrainer/favorite_locations.json` — начальный список избранных точек.
- `build/Build.bat` — сборка DLL системным C# compiler из .NET Framework с автоматическим запуском установщика.
- `Install_YnixTrainer.bat` — установка DLL и runtime-данных с резервным копированием предыдущей DLL.
- `Uninstall_YnixTrainer.bat` — удаление DLL или восстановление предыдущей версии без удаления настроек и JSON.
- `CHANGELOG_1_2_6_RU.md` — изменения текущего выпуска; `TEST_REPORT_1_2_6_RU.md` — статус проверок; `REGRESSION_TEST_PLAN_RU.md` — игровые сценарии.

## Требования
- GTA V Legacy.
- ScriptHookV и ScriptHookVDotNet2.
- Windows 7 x64 и .NET Framework 4.8.
- Проект нацелен на .NET Framework 4.0 API и C# 4 для совместимости с указанной средой.

## Сборка и автоматическая установка
1. Закрой GTA V.
2. Распакуй архив в отдельную рабочую папку, не в папку игры.
3. Запусти `build\Build.bat` обычным запуском. Установщик запросит UAC только при недостатке прав на запись в папку игры.
4. Скрипт проверит `ScriptHookVDotNet2.dll`, соберёт `dist\YnixTrainerExtended.dll`, а затем автоматически вызовет `Install_YnixTrainer.bat`.
5. Если стандартный путь не подошёл, укажи корневую папку GTA V. Сборщик ищет `ScriptHookVDotNet2.dll` как в корне игры, так и в `GTA V\scripts`.
6. Установщик поместит основную DLL в `GTA V\scripts\`, а данные — в `GTA V\scripts\YnixTrainer\`, включая `Vehicles\vehicles.json`. Дополнительно создаются резервные копии `Vehicles\vehicles_builtin.json`, `Vehicles\vehicle_catalog.json` и `addons_builtin.json`: загрузчик использует их, если основной пользовательский JSON повреждён.

Установщик не заменяет ScriptHookVDotNet2.dll, NativeUI.dll и NativeUI.xml. Эти сторонние компоненты остаются нетронутыми. Существующие `YnixTrainerExtended.ini`, `Config.ini`, `addons.json`, `vehicle_catalog.json` и `favorite_locations.json` сохраняются; недостающие runtime-файлы добавляются из архива. Перед заменой основной DLL создаётся резервная копия в `scripts\YnixTrainer_Backups\`. Если DLL обнаружена внутри `scripts\YnixTrainer\`, после успешной установки она переносится в эту же папку резервных копий, а не удаляется.

`Uninstall_YnixTrainer.bat` удаляет DLL трейнера или восстанавливает сохранённую предыдущую DLL. Пользовательские настройки и базы в `scripts\YnixTrainer\` не удаляются.

Архив содержит исходный код, а не готовую скомпилированную DLL. Сборка выполняется на ПК пользователя с установленными .NET Framework compiler tools и ScriptHookVDotNet2. Если `ScriptHookVDotNet2.dll` отсутствует и в корне GTA V, и в `scripts`, сначала восстанови эту зависимость. Новая DLL не заменяет старую при ошибке компиляции.

## Файлы после установки
```text
GTA V\scripts\
  YnixTrainerExtended.dll
  YnixTrainer_Logs\
    install.log
    session.log (создаётся при запуске скрипта)
    errors.log (создаётся при ошибке)
  YnixTrainer_Backups\
  YnixTrainer\
    YnixTrainerExtended.ini
    vehicle_catalog.json
    addons.json
    addons_builtin.json
    favorite_locations.json
    Vehicles\
      vehicles.json
      vehicles_builtin.json
```

Папка `Languages` и любые сторонние файлы внутри `scripts\YnixTrainer` не удаляются установщиком. Установщик обновляет только отсутствующие runtime-файлы данных и основную DLL.

## Управление
- `F11` — открыть / закрыть трейнер.
- `ESC` — закрыть трейнер; pause/front-end controls блокируются во время меню и короткий период после закрытия. Следующее отдельное нажатие ESC должно работать штатно.
- `↑ / ↓` — выбор пункта.
- `Enter` / `NumPad 5` — действие / открыть раздел.
- `Backspace` — назад.

## Настройки интерфейса
`Settings` → `Interface customization`:
- положение меню по горизонтали и вертикали;
- ширина меню;
- общий масштаб;
- размер шрифта;
- стиль шрифта (4 варианта);
- цветовая тема (красная, синяя, фиолетовая, зелёная, монохромная);
- прозрачность фона;
- число видимых строк (6–12);
- сброс настроек интерфейса.

Настройки автоматически сохраняются в секцию `[MENU]` файла `YnixTrainerExtended.ini`.

## Max Tuning
Функция назначает vehicle mod kit 0, выбирает доступный тип дисков (с приоритетом High End), применяет максимальные доступные индексы к поддерживаемым кузовным и performance-слотам, отдельно включает turbo/tyre smoke/xenon, задаёт Limo tint и включает защиту шин от разрыва. Результат и неподдерживаемые слоты записываются в журнал. На машинах без нужных деталей игра не может создать отсутствующие модификации.

Не у каждой служебной, специальной или Add-on модели есть полный mod kit. Трейнер не может добавить отсутствующие в модели детали.

## База транспорта и Add-on
В поставке 470 записей основной базы и 85 отдельно переданных Add-on записей; после объединения по Model ID проверено 540 уникальных кодов (15 повторов между двумя наборами удаляются при объединении). Файл JSON формирует каталог спавнера, но не устанавливает файлы Add-on-моделей в игру. Add-on транспорт должен быть предварительно установлен и корректно зарегистрирован в GTA V.

## Избранные точки
В разделе `Saved Locations` можно сохранить текущие координаты, перейти к точке, удалить одну точку или очистить список. Максимум — 100 точек. Они хранятся в `favorite_locations.json`.

## Журналы
- `YnixTrainer_Build.log` — сборка в корне распакованного проекта.
- `YnixTrainer_Install.log` — установка в корне распакованного проекта; его можно приложить, если установка не завершилась.
- `GTA V\scripts\YnixTrainer_Logs\install.log` — копия результата установки.

`GTA V\scripts\YnixTrainer_Logs\`:
- `session.log` — сессии и события;
- `errors.log` — обработанные ошибки;
- `crash_report.log` — отчёты об управляемых необработанных исключениях.

Нативное падение GTA, авария движка или принудительное завершение процесса могут произойти до записи отчёта. Журналирование не является универсальной защитой от вылета.

## Диагностика транспорта
- Основная база: `scripts\YnixTrainer\Vehicles\vehicles.json`. Совместимая копия: `scripts\YnixTrainer\vehicle_catalog.json`.
- Список add-on: `scripts\YnixTrainer\addons.json`.
- Ошибки: `scripts\YnixTrainer_Logs\errors.log`; обычные события: `session.log`. Если нет даже `session.log`, ScriptHookVDotNet2, вероятно, не загрузил DLL или конструктор скрипта не запустился; в таком случае приложи также `YnixTrainer_Build.log` и `YnixTrainer_Install.log`.
- Каталог включает названия моделей игры, но не устанавливает отдельные add-on assets. Для сторонних машин нужны установленные игровые файлы `.yft/.ytd` и соответствующие meta-файлы.
- Спавн проверяет модель в текущей сборке GTA. Модели, отсутствующие в build 1.0.2245.0, будут отклонены даже если их имя присутствует в JSON.
- После сборки и установки сначала проверь `adder` в Story Mode.
